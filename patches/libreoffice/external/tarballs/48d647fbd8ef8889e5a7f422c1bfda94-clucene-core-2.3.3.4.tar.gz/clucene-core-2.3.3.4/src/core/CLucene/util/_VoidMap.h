/*------------------------------------------------------------------------------
* Copyright (C) 2003-2006 Ben van Klinken and the CLucene Team
* 
* Distributable under the terms of either the Apache License (Version 2.0) or 
* the GNU Lesser General Public License, as specified in the COPYING file.
------------------------------------------------------------------------------*/
#ifndef _lucene_util_VoidsMap_
#define _lucene_util_VoidsMap_

	/*#if defined(_LUCENE_PRAGMA_WARNINGS)
	 #pragma message ("==================Deprecated!!!==================")
	#else
	 //#warning "==================Deprecated!!!=================="
	#endif
	
	#include "VoidMapSetDefinitions.h"*/
	
	#include "VoidMap.h"
#endif
