<!--
Copyright (C) 2016 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

## Break Iterator Rule Source Data

This directory contains rule based break iterator rule files, one set per file.

The set of rules to be included for each locale is defined in the parent directory, icu/icu4c/source/data/brkitr. Most locales fall back to root rules, which are from char.txt, word.txt, line.txt and sent.txt for, respectively, grapheme cluster, word, line and sentence breaks.

