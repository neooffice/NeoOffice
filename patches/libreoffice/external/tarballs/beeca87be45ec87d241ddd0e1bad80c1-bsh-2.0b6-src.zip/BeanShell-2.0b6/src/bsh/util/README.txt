
Nothing in the core should depend on the util package.

