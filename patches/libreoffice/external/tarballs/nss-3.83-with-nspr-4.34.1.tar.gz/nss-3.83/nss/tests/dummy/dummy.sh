#! /bin/bash
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

########################################################################
#
# mozilla/security/nss/tests/dummy/dummy.sh
#
# Minimal test that doesn't do anything
#
# NSS_TESTS="dummy" can be used for quick testing of the
#   test script infrastructure, without running any of the tests 
#
########################################################################

# html_failed "dummy test fail"
html_passed "dummy test ok"
