// This cpp is here to force cmake to make a project file for sajson.
int sajson_dummy;
