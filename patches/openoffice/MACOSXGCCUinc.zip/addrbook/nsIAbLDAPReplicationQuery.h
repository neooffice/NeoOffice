/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbLDAPReplicationQuery.idl
 */

#ifndef __gen_nsIAbLDAPReplicationQuery_h__
#define __gen_nsIAbLDAPReplicationQuery_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsDirPrefs.h"
class nsIWebProgressListener; /* forward declaration */

class nsILDAPURL; /* forward declaration */

class nsILDAPConnection; /* forward declaration */

class nsILDAPOperation; /* forward declaration */


/* starting interface:    nsIAbLDAPReplicationQuery */
#define NS_IABLDAPREPLICATIONQUERY_IID_STR "00d568a1-3c3b-11d6-b7b9-00b0d06e5f27"

#define NS_IABLDAPREPLICATIONQUERY_IID \
  {0x00d568a1, 0x3c3b, 0x11d6, \
    { 0xb7, 0xb9, 0x00, 0xb0, 0xd0, 0x6e, 0x5f, 0x27 }}

/**
 * this interface provides methods to perform LDAP Replication Queries
 */
class NS_NO_VTABLE nsIAbLDAPReplicationQuery : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPREPLICATIONQUERY_IID)

  /* readonly attribute nsILDAPURL replicationURL; */
  NS_IMETHOD GetReplicationURL(nsILDAPURL * *aReplicationURL) = 0;

  /* readonly attribute nsILDAPConnection connection; */
  NS_IMETHOD GetConnection(nsILDAPConnection * *aConnection) = 0;

  /* readonly attribute nsILDAPOperation operation; */
  NS_IMETHOD GetOperation(nsILDAPOperation * *aOperation) = 0;

  /* [noscript] readonly attribute DIR_Server replicationServerInfo; */
  NS_IMETHOD GetReplicationServerInfo(DIR_Server * *aReplicationServerInfo) = 0;

  /**
     * initialize for the query
     */
  /* void init (in ACString aPrefName, in nsIWebProgressListener aProgressListener); */
  NS_IMETHOD Init(const nsACString & aPrefName, nsIWebProgressListener *aProgressListener) = 0;

  /**
     * Starts an LDAP query to do replication as needed
     */
  /* void doReplicationQuery (); */
  NS_IMETHOD DoReplicationQuery(void) = 0;

  /**
     * connects to an LDAP Server using a DN
	 */
  /* void connectToLDAPServer (in nsILDAPURL aURL, in AUTF8String aAuthDN); */
  NS_IMETHOD ConnectToLDAPServer(nsILDAPURL *aURL, const nsACString & aAuthDN) = 0;

  /**
    * Starts an LDAP query to replicate all entries
    */
  /* void queryAllEntries (); */
  NS_IMETHOD QueryAllEntries(void) = 0;

  /**
     * Cancels the currently executing query
     */
  /* void cancelQuery (); */
  NS_IMETHOD CancelQuery(void) = 0;

  /**
     * this method is the callback when query is done, failed or successful
     */
  /* void done (in boolean aSuccess); */
  NS_IMETHOD Done(PRBool aSuccess) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPREPLICATIONQUERY \
  NS_IMETHOD GetReplicationURL(nsILDAPURL * *aReplicationURL); \
  NS_IMETHOD GetConnection(nsILDAPConnection * *aConnection); \
  NS_IMETHOD GetOperation(nsILDAPOperation * *aOperation); \
  NS_IMETHOD GetReplicationServerInfo(DIR_Server * *aReplicationServerInfo); \
  NS_IMETHOD Init(const nsACString & aPrefName, nsIWebProgressListener *aProgressListener); \
  NS_IMETHOD DoReplicationQuery(void); \
  NS_IMETHOD ConnectToLDAPServer(nsILDAPURL *aURL, const nsACString & aAuthDN); \
  NS_IMETHOD QueryAllEntries(void); \
  NS_IMETHOD CancelQuery(void); \
  NS_IMETHOD Done(PRBool aSuccess); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPREPLICATIONQUERY(_to) \
  NS_IMETHOD GetReplicationURL(nsILDAPURL * *aReplicationURL) { return _to GetReplicationURL(aReplicationURL); } \
  NS_IMETHOD GetConnection(nsILDAPConnection * *aConnection) { return _to GetConnection(aConnection); } \
  NS_IMETHOD GetOperation(nsILDAPOperation * *aOperation) { return _to GetOperation(aOperation); } \
  NS_IMETHOD GetReplicationServerInfo(DIR_Server * *aReplicationServerInfo) { return _to GetReplicationServerInfo(aReplicationServerInfo); } \
  NS_IMETHOD Init(const nsACString & aPrefName, nsIWebProgressListener *aProgressListener) { return _to Init(aPrefName, aProgressListener); } \
  NS_IMETHOD DoReplicationQuery(void) { return _to DoReplicationQuery(); } \
  NS_IMETHOD ConnectToLDAPServer(nsILDAPURL *aURL, const nsACString & aAuthDN) { return _to ConnectToLDAPServer(aURL, aAuthDN); } \
  NS_IMETHOD QueryAllEntries(void) { return _to QueryAllEntries(); } \
  NS_IMETHOD CancelQuery(void) { return _to CancelQuery(); } \
  NS_IMETHOD Done(PRBool aSuccess) { return _to Done(aSuccess); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPREPLICATIONQUERY(_to) \
  NS_IMETHOD GetReplicationURL(nsILDAPURL * *aReplicationURL) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetReplicationURL(aReplicationURL); } \
  NS_IMETHOD GetConnection(nsILDAPConnection * *aConnection) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetConnection(aConnection); } \
  NS_IMETHOD GetOperation(nsILDAPOperation * *aOperation) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOperation(aOperation); } \
  NS_IMETHOD GetReplicationServerInfo(DIR_Server * *aReplicationServerInfo) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetReplicationServerInfo(aReplicationServerInfo); } \
  NS_IMETHOD Init(const nsACString & aPrefName, nsIWebProgressListener *aProgressListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(aPrefName, aProgressListener); } \
  NS_IMETHOD DoReplicationQuery(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoReplicationQuery(); } \
  NS_IMETHOD ConnectToLDAPServer(nsILDAPURL *aURL, const nsACString & aAuthDN) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConnectToLDAPServer(aURL, aAuthDN); } \
  NS_IMETHOD QueryAllEntries(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->QueryAllEntries(); } \
  NS_IMETHOD CancelQuery(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelQuery(); } \
  NS_IMETHOD Done(PRBool aSuccess) { return !_to ? NS_ERROR_NULL_POINTER : _to->Done(aSuccess); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPReplicationQuery : public nsIAbLDAPReplicationQuery
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPREPLICATIONQUERY

  nsAbLDAPReplicationQuery();

private:
  ~nsAbLDAPReplicationQuery();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPReplicationQuery, nsIAbLDAPReplicationQuery)

nsAbLDAPReplicationQuery::nsAbLDAPReplicationQuery()
{
  /* member initializers and constructor code */
}

nsAbLDAPReplicationQuery::~nsAbLDAPReplicationQuery()
{
  /* destructor code */
}

/* readonly attribute nsILDAPURL replicationURL; */
NS_IMETHODIMP nsAbLDAPReplicationQuery::GetReplicationURL(nsILDAPURL * *aReplicationURL)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsILDAPConnection connection; */
NS_IMETHODIMP nsAbLDAPReplicationQuery::GetConnection(nsILDAPConnection * *aConnection)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsILDAPOperation operation; */
NS_IMETHODIMP nsAbLDAPReplicationQuery::GetOperation(nsILDAPOperation * *aOperation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute DIR_Server replicationServerInfo; */
NS_IMETHODIMP nsAbLDAPReplicationQuery::GetReplicationServerInfo(DIR_Server * *aReplicationServerInfo)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void init (in ACString aPrefName, in nsIWebProgressListener aProgressListener); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::Init(const nsACString & aPrefName, nsIWebProgressListener *aProgressListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doReplicationQuery (); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::DoReplicationQuery()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void connectToLDAPServer (in nsILDAPURL aURL, in AUTF8String aAuthDN); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::ConnectToLDAPServer(nsILDAPURL *aURL, const nsACString & aAuthDN)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void queryAllEntries (); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::QueryAllEntries()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void cancelQuery (); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::CancelQuery()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void done (in boolean aSuccess); */
NS_IMETHODIMP nsAbLDAPReplicationQuery::Done(PRBool aSuccess)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbLDAPChangeLogQuery */
#define NS_IABLDAPCHANGELOGQUERY_IID_STR "126202d1-4460-11d6-b7c2-00b0d06e5f27"

#define NS_IABLDAPCHANGELOGQUERY_IID \
  {0x126202d1, 0x4460, 0x11d6, \
    { 0xb7, 0xc2, 0x00, 0xb0, 0xd0, 0x6e, 0x5f, 0x27 }}

class NS_NO_VTABLE nsIAbLDAPChangeLogQuery : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPCHANGELOGQUERY_IID)

  /**
    * Starts an LDAP query to find auth DN
    */
  /* void queryAuthDN (in AUTF8String aValueUsedToFindDn); */
  NS_IMETHOD QueryAuthDN(const nsACString & aValueUsedToFindDn) = 0;

  /**
    * Starts an LDAP query to search server's Root DSE
    */
  /* void queryRootDSE (); */
  NS_IMETHOD QueryRootDSE(void) = 0;

  /**
    * Starts an LDAP ChangeLog query to find changelog entries
    */
  /* void queryChangeLog (in AUTF8String aChangeLogDN, in PRInt32 aLastChangeNo); */
  NS_IMETHOD QueryChangeLog(const nsACString & aChangeLogDN, PRInt32 aLastChangeNo) = 0;

  /**
    * Starts an LDAP query to find changed entries
    */
  /* void queryChangedEntries (in AUTF8String aChangedEntryDN); */
  NS_IMETHOD QueryChangedEntries(const nsACString & aChangedEntryDN) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPCHANGELOGQUERY \
  NS_IMETHOD QueryAuthDN(const nsACString & aValueUsedToFindDn); \
  NS_IMETHOD QueryRootDSE(void); \
  NS_IMETHOD QueryChangeLog(const nsACString & aChangeLogDN, PRInt32 aLastChangeNo); \
  NS_IMETHOD QueryChangedEntries(const nsACString & aChangedEntryDN); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPCHANGELOGQUERY(_to) \
  NS_IMETHOD QueryAuthDN(const nsACString & aValueUsedToFindDn) { return _to QueryAuthDN(aValueUsedToFindDn); } \
  NS_IMETHOD QueryRootDSE(void) { return _to QueryRootDSE(); } \
  NS_IMETHOD QueryChangeLog(const nsACString & aChangeLogDN, PRInt32 aLastChangeNo) { return _to QueryChangeLog(aChangeLogDN, aLastChangeNo); } \
  NS_IMETHOD QueryChangedEntries(const nsACString & aChangedEntryDN) { return _to QueryChangedEntries(aChangedEntryDN); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPCHANGELOGQUERY(_to) \
  NS_IMETHOD QueryAuthDN(const nsACString & aValueUsedToFindDn) { return !_to ? NS_ERROR_NULL_POINTER : _to->QueryAuthDN(aValueUsedToFindDn); } \
  NS_IMETHOD QueryRootDSE(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->QueryRootDSE(); } \
  NS_IMETHOD QueryChangeLog(const nsACString & aChangeLogDN, PRInt32 aLastChangeNo) { return !_to ? NS_ERROR_NULL_POINTER : _to->QueryChangeLog(aChangeLogDN, aLastChangeNo); } \
  NS_IMETHOD QueryChangedEntries(const nsACString & aChangedEntryDN) { return !_to ? NS_ERROR_NULL_POINTER : _to->QueryChangedEntries(aChangedEntryDN); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPChangeLogQuery : public nsIAbLDAPChangeLogQuery
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPCHANGELOGQUERY

  nsAbLDAPChangeLogQuery();

private:
  ~nsAbLDAPChangeLogQuery();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPChangeLogQuery, nsIAbLDAPChangeLogQuery)

nsAbLDAPChangeLogQuery::nsAbLDAPChangeLogQuery()
{
  /* member initializers and constructor code */
}

nsAbLDAPChangeLogQuery::~nsAbLDAPChangeLogQuery()
{
  /* destructor code */
}

/* void queryAuthDN (in AUTF8String aValueUsedToFindDn); */
NS_IMETHODIMP nsAbLDAPChangeLogQuery::QueryAuthDN(const nsACString & aValueUsedToFindDn)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void queryRootDSE (); */
NS_IMETHODIMP nsAbLDAPChangeLogQuery::QueryRootDSE()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void queryChangeLog (in AUTF8String aChangeLogDN, in PRInt32 aLastChangeNo); */
NS_IMETHODIMP nsAbLDAPChangeLogQuery::QueryChangeLog(const nsACString & aChangeLogDN, PRInt32 aLastChangeNo)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void queryChangedEntries (in AUTF8String aChangedEntryDN); */
NS_IMETHODIMP nsAbLDAPChangeLogQuery::QueryChangedEntries(const nsACString & aChangedEntryDN)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDAPReplicationQuery_h__ */
