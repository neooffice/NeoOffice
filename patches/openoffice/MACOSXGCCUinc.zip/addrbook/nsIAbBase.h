/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbBase.idl
 */

#ifndef __gen_nsIAbBase_h__
#define __gen_nsIAbBase_h__


#ifndef __gen_nsICollection_h__
#include "nsICollection.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbBase */
#define NS_IABBASE_IID_STR "013dd009-f73b-11d2-a2da-001083003d0c"

#define NS_IABBASE_IID \
  {0x013dd009, 0xf73b, 0x11d2, \
    { 0xa2, 0xda, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAbBase : public nsICollection {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABBASE_IID)

  /* readonly attribute string URI; */
  NS_IMETHOD GetURI(char * *aURI) = 0;

  /* attribute string name; */
  NS_IMETHOD GetName(char * *aName) = 0;
  NS_IMETHOD SetName(const char * aName) = 0;

  /* nsISupports GetChildNamed (in string name); */
  NS_IMETHOD GetChildNamed(const char *name, nsISupports **_retval) = 0;

  /* attribute nsIAbBase parent; */
  NS_IMETHOD GetParent(nsIAbBase * *aParent) = 0;
  NS_IMETHOD SetParent(nsIAbBase * aParent) = 0;

  /* nsISimpleEnumerator GetChildNodes (); */
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABBASE \
  NS_IMETHOD GetURI(char * *aURI); \
  NS_IMETHOD GetName(char * *aName); \
  NS_IMETHOD SetName(const char * aName); \
  NS_IMETHOD GetChildNamed(const char *name, nsISupports **_retval); \
  NS_IMETHOD GetParent(nsIAbBase * *aParent); \
  NS_IMETHOD SetParent(nsIAbBase * aParent); \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABBASE(_to) \
  NS_IMETHOD GetURI(char * *aURI) { return _to GetURI(aURI); } \
  NS_IMETHOD GetName(char * *aName) { return _to GetName(aName); } \
  NS_IMETHOD SetName(const char * aName) { return _to SetName(aName); } \
  NS_IMETHOD GetChildNamed(const char *name, nsISupports **_retval) { return _to GetChildNamed(name, _retval); } \
  NS_IMETHOD GetParent(nsIAbBase * *aParent) { return _to GetParent(aParent); } \
  NS_IMETHOD SetParent(nsIAbBase * aParent) { return _to SetParent(aParent); } \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator **_retval) { return _to GetChildNodes(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABBASE(_to) \
  NS_IMETHOD GetURI(char * *aURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetURI(aURI); } \
  NS_IMETHOD GetName(char * *aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(aName); } \
  NS_IMETHOD SetName(const char * aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetName(aName); } \
  NS_IMETHOD GetChildNamed(const char *name, nsISupports **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildNamed(name, _retval); } \
  NS_IMETHOD GetParent(nsIAbBase * *aParent) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetParent(aParent); } \
  NS_IMETHOD SetParent(nsIAbBase * aParent) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetParent(aParent); } \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildNodes(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbBase : public nsIAbBase
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABBASE

  nsAbBase();

private:
  ~nsAbBase();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbBase, nsIAbBase)

nsAbBase::nsAbBase()
{
  /* member initializers and constructor code */
}

nsAbBase::~nsAbBase()
{
  /* destructor code */
}

/* readonly attribute string URI; */
NS_IMETHODIMP nsAbBase::GetURI(char * *aURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string name; */
NS_IMETHODIMP nsAbBase::GetName(char * *aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBase::SetName(const char * aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsISupports GetChildNamed (in string name); */
NS_IMETHODIMP nsAbBase::GetChildNamed(const char *name, nsISupports **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsIAbBase parent; */
NS_IMETHODIMP nsAbBase::GetParent(nsIAbBase * *aParent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBase::SetParent(nsIAbBase * aParent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsISimpleEnumerator GetChildNodes (); */
NS_IMETHODIMP nsAbBase::GetChildNodes(nsISimpleEnumerator **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbBase_h__ */
