/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbAutoCompleteSession.idl
 */

#ifndef __gen_nsIAbAutoCompleteSession_h__
#define __gen_nsIAbAutoCompleteSession_h__


#ifndef __gen_nsIAutoCompleteSession_h__
#include "nsIAutoCompleteSession.h"
#endif

#ifndef __gen_nsIMsgIdentity_h__
#include "nsIMsgIdentity.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbAutoCompleteSession */
#define NS_IABAUTOCOMPLETESESSION_IID_STR "ca2a6b07-3625-11d3-988e-001083010e9b"

#define NS_IABAUTOCOMPLETESESSION_IID \
  {0xca2a6b07, 0x3625, 0x11d3, \
    { 0x98, 0x8e, 0x00, 0x10, 0x83, 0x01, 0x0e, 0x9b }}

class NS_NO_VTABLE nsIAbAutoCompleteSession : public nsIAutoCompleteSession {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABAUTOCOMPLETESESSION_IID)

  /* attribute wstring defaultDomain; */
  NS_IMETHOD GetDefaultDomain(PRUnichar * *aDefaultDomain) = 0;
  NS_IMETHOD SetDefaultDomain(const PRUnichar * aDefaultDomain) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABAUTOCOMPLETESESSION \
  NS_IMETHOD GetDefaultDomain(PRUnichar * *aDefaultDomain); \
  NS_IMETHOD SetDefaultDomain(const PRUnichar * aDefaultDomain); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABAUTOCOMPLETESESSION(_to) \
  NS_IMETHOD GetDefaultDomain(PRUnichar * *aDefaultDomain) { return _to GetDefaultDomain(aDefaultDomain); } \
  NS_IMETHOD SetDefaultDomain(const PRUnichar * aDefaultDomain) { return _to SetDefaultDomain(aDefaultDomain); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABAUTOCOMPLETESESSION(_to) \
  NS_IMETHOD GetDefaultDomain(PRUnichar * *aDefaultDomain) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDefaultDomain(aDefaultDomain); } \
  NS_IMETHOD SetDefaultDomain(const PRUnichar * aDefaultDomain) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDefaultDomain(aDefaultDomain); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbAutoCompleteSession : public nsIAbAutoCompleteSession
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABAUTOCOMPLETESESSION

  nsAbAutoCompleteSession();

private:
  ~nsAbAutoCompleteSession();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbAutoCompleteSession, nsIAbAutoCompleteSession)

nsAbAutoCompleteSession::nsAbAutoCompleteSession()
{
  /* member initializers and constructor code */
}

nsAbAutoCompleteSession::~nsAbAutoCompleteSession()
{
  /* destructor code */
}

/* attribute wstring defaultDomain; */
NS_IMETHODIMP nsAbAutoCompleteSession::GetDefaultDomain(PRUnichar * *aDefaultDomain)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbAutoCompleteSession::SetDefaultDomain(const PRUnichar * aDefaultDomain)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbAutoCompleteSession_h__ */
