/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbLDAPAutoCompFormatter.idl
 */

#ifndef __gen_nsIAbLDAPAutoCompFormatter_h__
#define __gen_nsIAbLDAPAutoCompFormatter_h__


#ifndef __gen_nsILDAPAutoCompFormatter_h__
#include "nsILDAPAutoCompFormatter.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbLDAPAutoCompFormatter */
#define NS_IABLDAPAUTOCOMPFORMATTER_IID_STR "cde8836e-1dd1-11b2-baff-a6d918243e80"

#define NS_IABLDAPAUTOCOMPFORMATTER_IID \
  {0xcde8836e, 0x1dd1, 0x11b2, \
    { 0xba, 0xff, 0xa6, 0xd9, 0x18, 0x24, 0x3e, 0x80 }}

/** 
 * An interface for formatter LDAP messages to be used as nsAutoCompleteItems
 * for use in RFC 2822 message headers.
 */
class NS_NO_VTABLE nsIAbLDAPAutoCompFormatter : public nsILDAPAutoCompFormatter {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPAUTOCOMPFORMATTER_IID)

  /**
     * All three Format attributes are templates, which work as follows:
     *
     * Required LDAP attributes are delimited by curly braces, and
     * optional LDAP attributes are determined by brackets.  Backslash
     * escapes any character, including itself.  Someday perhaps we'll rev 
     * this interface and change these to a more flexible format; perhaps 
     * something regexp based.
     *
     * If any of these are unset, components implementing this interface 
     * are free to choose reasonable defaults.  As an example, the 
     *"@mozilla.org/ldap-autocomplete-formatter;1?type=addrbook"
     * implementation currently happens to use the following default
     * strings:
     * 
     * nameFormat: "[cn]"
     * addressFormat: "{mail}"
     * commentFormat: ""
     *
     * and generates autocomplete items like this:
     *
     * value: John Doe <john.doe@foo.org>         
     * comment: Foo Organization
     *
     * Note that nsILDAPAutoCompFormatter::getAttributes() is only
     * required to be called by the nsILDAPAutoCompleteSession
     * implementation when the nsILDAPAutoCompleteSession::formatter
     * IDL attribute is set.  So if for some reason the format
     * attributes exposed through this interface get changed (eg a
     * user changes their prefs), it is the changing code's
     * responsibly to re-set the nsILDAPAutoCompleteSession::formatter
     * IDL attribute to the same object to force a new getAttributes()
     * call.
     */
  /* attribute AString nameFormat; */
  NS_IMETHOD GetNameFormat(nsAString & aNameFormat) = 0;
  NS_IMETHOD SetNameFormat(const nsAString & aNameFormat) = 0;

  /* attribute AString addressFormat; */
  NS_IMETHOD GetAddressFormat(nsAString & aAddressFormat) = 0;
  NS_IMETHOD SetAddressFormat(const nsAString & aAddressFormat) = 0;

  /* attribute AString commentFormat; */
  NS_IMETHOD GetCommentFormat(nsAString & aCommentFormat) = 0;
  NS_IMETHOD SetCommentFormat(const nsAString & aCommentFormat) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPAUTOCOMPFORMATTER \
  NS_IMETHOD GetNameFormat(nsAString & aNameFormat); \
  NS_IMETHOD SetNameFormat(const nsAString & aNameFormat); \
  NS_IMETHOD GetAddressFormat(nsAString & aAddressFormat); \
  NS_IMETHOD SetAddressFormat(const nsAString & aAddressFormat); \
  NS_IMETHOD GetCommentFormat(nsAString & aCommentFormat); \
  NS_IMETHOD SetCommentFormat(const nsAString & aCommentFormat); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPAUTOCOMPFORMATTER(_to) \
  NS_IMETHOD GetNameFormat(nsAString & aNameFormat) { return _to GetNameFormat(aNameFormat); } \
  NS_IMETHOD SetNameFormat(const nsAString & aNameFormat) { return _to SetNameFormat(aNameFormat); } \
  NS_IMETHOD GetAddressFormat(nsAString & aAddressFormat) { return _to GetAddressFormat(aAddressFormat); } \
  NS_IMETHOD SetAddressFormat(const nsAString & aAddressFormat) { return _to SetAddressFormat(aAddressFormat); } \
  NS_IMETHOD GetCommentFormat(nsAString & aCommentFormat) { return _to GetCommentFormat(aCommentFormat); } \
  NS_IMETHOD SetCommentFormat(const nsAString & aCommentFormat) { return _to SetCommentFormat(aCommentFormat); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPAUTOCOMPFORMATTER(_to) \
  NS_IMETHOD GetNameFormat(nsAString & aNameFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNameFormat(aNameFormat); } \
  NS_IMETHOD SetNameFormat(const nsAString & aNameFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNameFormat(aNameFormat); } \
  NS_IMETHOD GetAddressFormat(nsAString & aAddressFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAddressFormat(aAddressFormat); } \
  NS_IMETHOD SetAddressFormat(const nsAString & aAddressFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAddressFormat(aAddressFormat); } \
  NS_IMETHOD GetCommentFormat(nsAString & aCommentFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCommentFormat(aCommentFormat); } \
  NS_IMETHOD SetCommentFormat(const nsAString & aCommentFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCommentFormat(aCommentFormat); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPAutoCompFormatter : public nsIAbLDAPAutoCompFormatter
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPAUTOCOMPFORMATTER

  nsAbLDAPAutoCompFormatter();

private:
  ~nsAbLDAPAutoCompFormatter();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPAutoCompFormatter, nsIAbLDAPAutoCompFormatter)

nsAbLDAPAutoCompFormatter::nsAbLDAPAutoCompFormatter()
{
  /* member initializers and constructor code */
}

nsAbLDAPAutoCompFormatter::~nsAbLDAPAutoCompFormatter()
{
  /* destructor code */
}

/* attribute AString nameFormat; */
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::GetNameFormat(nsAString & aNameFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::SetNameFormat(const nsAString & aNameFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute AString addressFormat; */
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::GetAddressFormat(nsAString & aAddressFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::SetAddressFormat(const nsAString & aAddressFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute AString commentFormat; */
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::GetCommentFormat(nsAString & aCommentFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbLDAPAutoCompFormatter::SetCommentFormat(const nsAString & aCommentFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDAPAutoCompFormatter_h__ */
