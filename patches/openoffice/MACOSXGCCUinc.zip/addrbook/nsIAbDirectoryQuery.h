/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbDirectoryQuery.idl
 */

#ifndef __gen_nsIAbDirectoryQuery_h__
#define __gen_nsIAbDirectoryQuery_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

#ifndef __gen_nsIAbBooleanExpression_h__
#include "nsIAbBooleanExpression.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbDirectoryQueryArguments */
#define NS_IABDIRECTORYQUERYARGUMENTS_IID_STR "41ec291e-1dd2-11b2-b583-c44757081f64"

#define NS_IABDIRECTORYQUERYARGUMENTS_IID \
  {0x41ec291e, 0x1dd2, 0x11b2, \
    { 0xb5, 0x83, 0xc4, 0x47, 0x57, 0x08, 0x1f, 0x64 }}

/**
 * The arguments for a query.
 *
 * Contains an expression for perform matches
 * and an array of properties which should be
 * returned if a match is found from the expression
 *
 */
class NS_NO_VTABLE nsIAbDirectoryQueryArguments : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERYARGUMENTS_IID)

  /**
     * Defines the boolean expression for
     * the matching of cards
     *
     */
  /* attribute nsISupports expression; */
  NS_IMETHOD GetExpression(nsISupports * *aExpression) = 0;
  NS_IMETHOD SetExpression(nsISupports * aExpression) = 0;

  /**
     * Defines if sub directories should be
     * queried 
     *
     */
  /* attribute boolean querySubDirectories; */
  NS_IMETHOD GetQuerySubDirectories(PRBool *aQuerySubDirectories) = 0;
  NS_IMETHOD SetQuerySubDirectories(PRBool aQuerySubDirectories) = 0;

  /**
     * The list of properties which should
     * be returned if a match occurs on a card
     *
     */
  /* void setReturnProperties (in unsigned long returnPropertiesSize, [array, size_is (returnPropertiesSize)] in string returnPropertiesArray); */
  NS_IMETHOD SetReturnProperties(PRUint32 returnPropertiesSize, const char **returnPropertiesArray) = 0;

  /* void getReturnProperties (out unsigned long returnPropertiesSize, [array, size_is (returnPropertiesSize), retval] out string returnPropertiesArray); */
  NS_IMETHOD GetReturnProperties(PRUint32 *returnPropertiesSize, char ***returnPropertiesArray) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERYARGUMENTS \
  NS_IMETHOD GetExpression(nsISupports * *aExpression); \
  NS_IMETHOD SetExpression(nsISupports * aExpression); \
  NS_IMETHOD GetQuerySubDirectories(PRBool *aQuerySubDirectories); \
  NS_IMETHOD SetQuerySubDirectories(PRBool aQuerySubDirectories); \
  NS_IMETHOD SetReturnProperties(PRUint32 returnPropertiesSize, const char **returnPropertiesArray); \
  NS_IMETHOD GetReturnProperties(PRUint32 *returnPropertiesSize, char ***returnPropertiesArray); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERYARGUMENTS(_to) \
  NS_IMETHOD GetExpression(nsISupports * *aExpression) { return _to GetExpression(aExpression); } \
  NS_IMETHOD SetExpression(nsISupports * aExpression) { return _to SetExpression(aExpression); } \
  NS_IMETHOD GetQuerySubDirectories(PRBool *aQuerySubDirectories) { return _to GetQuerySubDirectories(aQuerySubDirectories); } \
  NS_IMETHOD SetQuerySubDirectories(PRBool aQuerySubDirectories) { return _to SetQuerySubDirectories(aQuerySubDirectories); } \
  NS_IMETHOD SetReturnProperties(PRUint32 returnPropertiesSize, const char **returnPropertiesArray) { return _to SetReturnProperties(returnPropertiesSize, returnPropertiesArray); } \
  NS_IMETHOD GetReturnProperties(PRUint32 *returnPropertiesSize, char ***returnPropertiesArray) { return _to GetReturnProperties(returnPropertiesSize, returnPropertiesArray); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERYARGUMENTS(_to) \
  NS_IMETHOD GetExpression(nsISupports * *aExpression) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetExpression(aExpression); } \
  NS_IMETHOD SetExpression(nsISupports * aExpression) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetExpression(aExpression); } \
  NS_IMETHOD GetQuerySubDirectories(PRBool *aQuerySubDirectories) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetQuerySubDirectories(aQuerySubDirectories); } \
  NS_IMETHOD SetQuerySubDirectories(PRBool aQuerySubDirectories) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetQuerySubDirectories(aQuerySubDirectories); } \
  NS_IMETHOD SetReturnProperties(PRUint32 returnPropertiesSize, const char **returnPropertiesArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetReturnProperties(returnPropertiesSize, returnPropertiesArray); } \
  NS_IMETHOD GetReturnProperties(PRUint32 *returnPropertiesSize, char ***returnPropertiesArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetReturnProperties(returnPropertiesSize, returnPropertiesArray); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQueryArguments : public nsIAbDirectoryQueryArguments
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERYARGUMENTS

  nsAbDirectoryQueryArguments();

private:
  ~nsAbDirectoryQueryArguments();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQueryArguments, nsIAbDirectoryQueryArguments)

nsAbDirectoryQueryArguments::nsAbDirectoryQueryArguments()
{
  /* member initializers and constructor code */
}

nsAbDirectoryQueryArguments::~nsAbDirectoryQueryArguments()
{
  /* destructor code */
}

/* attribute nsISupports expression; */
NS_IMETHODIMP nsAbDirectoryQueryArguments::GetExpression(nsISupports * *aExpression)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryQueryArguments::SetExpression(nsISupports * aExpression)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean querySubDirectories; */
NS_IMETHODIMP nsAbDirectoryQueryArguments::GetQuerySubDirectories(PRBool *aQuerySubDirectories)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryQueryArguments::SetQuerySubDirectories(PRBool aQuerySubDirectories)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setReturnProperties (in unsigned long returnPropertiesSize, [array, size_is (returnPropertiesSize)] in string returnPropertiesArray); */
NS_IMETHODIMP nsAbDirectoryQueryArguments::SetReturnProperties(PRUint32 returnPropertiesSize, const char **returnPropertiesArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getReturnProperties (out unsigned long returnPropertiesSize, [array, size_is (returnPropertiesSize), retval] out string returnPropertiesArray); */
NS_IMETHODIMP nsAbDirectoryQueryArguments::GetReturnProperties(PRUint32 *returnPropertiesSize, char ***returnPropertiesArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbDirectoryQueryPropertyValue */
#define NS_IABDIRECTORYQUERYPROPERTYVALUE_IID_STR "3a6e0c0c-1dd2-11b2-b23d-ea3a8ccb333c"

#define NS_IABDIRECTORYQUERYPROPERTYVALUE_IID \
  {0x3a6e0c0c, 0x1dd2, 0x11b2, \
    { 0xb2, 0x3d, 0xea, 0x3a, 0x8c, 0xcb, 0x33, 0x3c }}

class NS_NO_VTABLE nsIAbDirectoryQueryPropertyValue : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERYPROPERTYVALUE_IID)

  /**
     * The property which should be matched
     *
     * For example 'primaryEmail' or 'homePhone'
     * for card properties.
     *
     * Two further properties are defined that 
     * do not exist as properties on a card.
     *
     * 'card:nsIAbCard' which represents the interface
     * of a card component
     *
     */
  /* readonly attribute string name; */
  NS_IMETHOD GetName(char * *aName) = 0;

  /**
     * The value of the property
     *
     */
  /* readonly attribute wstring value; */
  NS_IMETHOD GetValue(PRUnichar * *aValue) = 0;

  /**
     * The value of the property
     * as an interface
     *
     * Only valid if the corresponding
     * property name is related to an
     * interface instead of a wstring
     *
     */
  /* readonly attribute nsISupports valueISupports; */
  NS_IMETHOD GetValueISupports(nsISupports * *aValueISupports) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERYPROPERTYVALUE \
  NS_IMETHOD GetName(char * *aName); \
  NS_IMETHOD GetValue(PRUnichar * *aValue); \
  NS_IMETHOD GetValueISupports(nsISupports * *aValueISupports); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERYPROPERTYVALUE(_to) \
  NS_IMETHOD GetName(char * *aName) { return _to GetName(aName); } \
  NS_IMETHOD GetValue(PRUnichar * *aValue) { return _to GetValue(aValue); } \
  NS_IMETHOD GetValueISupports(nsISupports * *aValueISupports) { return _to GetValueISupports(aValueISupports); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERYPROPERTYVALUE(_to) \
  NS_IMETHOD GetName(char * *aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(aName); } \
  NS_IMETHOD GetValue(PRUnichar * *aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetValue(aValue); } \
  NS_IMETHOD GetValueISupports(nsISupports * *aValueISupports) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetValueISupports(aValueISupports); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQueryPropertyValue : public nsIAbDirectoryQueryPropertyValue
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERYPROPERTYVALUE

  nsAbDirectoryQueryPropertyValue();

private:
  ~nsAbDirectoryQueryPropertyValue();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQueryPropertyValue, nsIAbDirectoryQueryPropertyValue)

nsAbDirectoryQueryPropertyValue::nsAbDirectoryQueryPropertyValue()
{
  /* member initializers and constructor code */
}

nsAbDirectoryQueryPropertyValue::~nsAbDirectoryQueryPropertyValue()
{
  /* destructor code */
}

/* readonly attribute string name; */
NS_IMETHODIMP nsAbDirectoryQueryPropertyValue::GetName(char * *aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute wstring value; */
NS_IMETHODIMP nsAbDirectoryQueryPropertyValue::GetValue(PRUnichar * *aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsISupports valueISupports; */
NS_IMETHODIMP nsAbDirectoryQueryPropertyValue::GetValueISupports(nsISupports * *aValueISupports)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbDirectoryQueryResult */
#define NS_IABDIRECTORYQUERYRESULT_IID_STR "42e600ba-1dd2-11b2-bc39-c363ac0c93e3"

#define NS_IABDIRECTORYQUERYRESULT_IID \
  {0x42e600ba, 0x1dd2, 0x11b2, \
    { 0xbc, 0x39, 0xc3, 0x63, 0xac, 0x0c, 0x93, 0xe3 }}

class NS_NO_VTABLE nsIAbDirectoryQueryResult : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERYRESULT_IID)

  /**
     * The context ID of the query
     *
     */
  /* readonly attribute long contextID; */
  NS_IMETHOD GetContextID(PRInt32 *aContextID) = 0;

  /**
     * The context of the query which
     * corresponds to the arguments that
     * define the query
     *
     */
  /* readonly attribute nsIAbDirectoryQueryArguments contextArgs; */
  NS_IMETHOD GetContextArgs(nsIAbDirectoryQueryArguments * *aContextArgs) = 0;

  /**
     * List of defined query results
     *
     */
  enum { queryResultMatch = 0 };

  enum { queryResultComplete = 1 };

  enum { queryResultStopped = 2 };

  enum { queryResultError = 3 };

  /**
     * The type of result
     *
     * Identifies a query entry, the query has finished
     * or that an error has occured
     */
  /* readonly attribute long type; */
  NS_IMETHOD GetType(PRInt32 *aType) = 0;

  /**
     * The result of a singular match for a card
     *
     * Only valid when the attribute type is
     * of 'query match'
     *
     * nsISupportsArray<nsIAbDirectoryQueryPropertyValue>
     *        Multiple entries corresponding to card
     *        properties
     * nsISupportsArray<nsIAbCard>
     *        Only one entry makese sense
     * 
     */
  /* readonly attribute nsISupportsArray result; */
  NS_IMETHOD GetResult(nsISupportsArray * *aResult) = 0;

  /**
     * result attribute defined explicitly as an
     * array of nsISupport interfaces
     *
     */
  /* void agetResult (out unsigned long aResultSize, [array, size_is (aResultSize), retval] out nsISupports aResultArray); */
  NS_IMETHOD AgetResult(PRUint32 *aResultSize, nsISupports ***aResultArray) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERYRESULT \
  NS_IMETHOD GetContextID(PRInt32 *aContextID); \
  NS_IMETHOD GetContextArgs(nsIAbDirectoryQueryArguments * *aContextArgs); \
  NS_IMETHOD GetType(PRInt32 *aType); \
  NS_IMETHOD GetResult(nsISupportsArray * *aResult); \
  NS_IMETHOD AgetResult(PRUint32 *aResultSize, nsISupports ***aResultArray); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERYRESULT(_to) \
  NS_IMETHOD GetContextID(PRInt32 *aContextID) { return _to GetContextID(aContextID); } \
  NS_IMETHOD GetContextArgs(nsIAbDirectoryQueryArguments * *aContextArgs) { return _to GetContextArgs(aContextArgs); } \
  NS_IMETHOD GetType(PRInt32 *aType) { return _to GetType(aType); } \
  NS_IMETHOD GetResult(nsISupportsArray * *aResult) { return _to GetResult(aResult); } \
  NS_IMETHOD AgetResult(PRUint32 *aResultSize, nsISupports ***aResultArray) { return _to AgetResult(aResultSize, aResultArray); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERYRESULT(_to) \
  NS_IMETHOD GetContextID(PRInt32 *aContextID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetContextID(aContextID); } \
  NS_IMETHOD GetContextArgs(nsIAbDirectoryQueryArguments * *aContextArgs) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetContextArgs(aContextArgs); } \
  NS_IMETHOD GetType(PRInt32 *aType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetType(aType); } \
  NS_IMETHOD GetResult(nsISupportsArray * *aResult) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetResult(aResult); } \
  NS_IMETHOD AgetResult(PRUint32 *aResultSize, nsISupports ***aResultArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->AgetResult(aResultSize, aResultArray); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQueryResult : public nsIAbDirectoryQueryResult
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERYRESULT

  nsAbDirectoryQueryResult();

private:
  ~nsAbDirectoryQueryResult();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQueryResult, nsIAbDirectoryQueryResult)

nsAbDirectoryQueryResult::nsAbDirectoryQueryResult()
{
  /* member initializers and constructor code */
}

nsAbDirectoryQueryResult::~nsAbDirectoryQueryResult()
{
  /* destructor code */
}

/* readonly attribute long contextID; */
NS_IMETHODIMP nsAbDirectoryQueryResult::GetContextID(PRInt32 *aContextID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIAbDirectoryQueryArguments contextArgs; */
NS_IMETHODIMP nsAbDirectoryQueryResult::GetContextArgs(nsIAbDirectoryQueryArguments * *aContextArgs)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute long type; */
NS_IMETHODIMP nsAbDirectoryQueryResult::GetType(PRInt32 *aType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsISupportsArray result; */
NS_IMETHODIMP nsAbDirectoryQueryResult::GetResult(nsISupportsArray * *aResult)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void agetResult (out unsigned long aResultSize, [array, size_is (aResultSize), retval] out nsISupports aResultArray); */
NS_IMETHODIMP nsAbDirectoryQueryResult::AgetResult(PRUint32 *aResultSize, nsISupports ***aResultArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbDirectoryQueryResultListener */
#define NS_IABDIRECTORYQUERYRESULTLISTENER_IID_STR "4290e508-1dd2-11b2-ac3e-9597bbcb25d7"

#define NS_IABDIRECTORYQUERYRESULTLISTENER_IID \
  {0x4290e508, 0x1dd2, 0x11b2, \
    { 0xac, 0x3e, 0x95, 0x97, 0xbb, 0xcb, 0x25, 0xd7 }}

class NS_NO_VTABLE nsIAbDirectoryQueryResultListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERYRESULTLISTENER_IID)

  /**
     * Called when a match is found. May be
     * called from a different thread to the
     * one that initiates the query
     *
     * @param result
     *        A individual result associated returned
     *        from a query
     */
  /* void onQueryItem (in nsIAbDirectoryQueryResult result); */
  NS_IMETHOD OnQueryItem(nsIAbDirectoryQueryResult *result) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERYRESULTLISTENER \
  NS_IMETHOD OnQueryItem(nsIAbDirectoryQueryResult *result); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERYRESULTLISTENER(_to) \
  NS_IMETHOD OnQueryItem(nsIAbDirectoryQueryResult *result) { return _to OnQueryItem(result); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERYRESULTLISTENER(_to) \
  NS_IMETHOD OnQueryItem(nsIAbDirectoryQueryResult *result) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnQueryItem(result); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQueryResultListener : public nsIAbDirectoryQueryResultListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERYRESULTLISTENER

  nsAbDirectoryQueryResultListener();

private:
  ~nsAbDirectoryQueryResultListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQueryResultListener, nsIAbDirectoryQueryResultListener)

nsAbDirectoryQueryResultListener::nsAbDirectoryQueryResultListener()
{
  /* member initializers and constructor code */
}

nsAbDirectoryQueryResultListener::~nsAbDirectoryQueryResultListener()
{
  /* destructor code */
}

/* void onQueryItem (in nsIAbDirectoryQueryResult result); */
NS_IMETHODIMP nsAbDirectoryQueryResultListener::OnQueryItem(nsIAbDirectoryQueryResult *result)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbDirectoryQuery */
#define NS_IABDIRECTORYQUERY_IID_STR "4241c46e-1dd2-11b2-978d-a2fbd0a72ac2"

#define NS_IABDIRECTORYQUERY_IID \
  {0x4241c46e, 0x1dd2, 0x11b2, \
    { 0x97, 0x8d, 0xa2, 0xfb, 0xd0, 0xa7, 0x2a, 0xc2 }}

class NS_NO_VTABLE nsIAbDirectoryQuery : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYQUERY_IID)

  /**
     * Initiates a query on a directory and 
     * sub-directories for properties on cards
     *
     * @param arguments
     *        The properties and values to match
     *        Value could of type nsIAbDirectoryQueryMatchItem
     *        for matches other than ?contains?
     * @param listener
     *        The listener which will obtain individual
     *        query results
     * @param resultLimit
     *        Limits the results returned to a specifed
     *        maximum value
     * @return
     *        Unique number representing the context ID of
     *        the query
     *
     */
  /* long doQuery (in nsIAbDirectoryQueryArguments arguments, in nsIAbDirectoryQueryResultListener listener, in long resultLimit, in long timeOut); */
  NS_IMETHOD DoQuery(nsIAbDirectoryQueryArguments *arguments, nsIAbDirectoryQueryResultListener *listener, PRInt32 resultLimit, PRInt32 timeOut, PRInt32 *_retval) = 0;

  /**
     * Stops an existing query operation if
     * query operation is asynchronous
     *
     * The nsIAbDirectoryQueryResultListener will
     * be notified when query has stopped
     *
     * It is implementation specific if notification
     * synchronous or asynchronous
     *
     * @param contextID
     *        The unique number returned from
     *        the doQuery methods
     *
     */
  /* void stopQuery (in long contextID); */
  NS_IMETHOD StopQuery(PRInt32 contextID) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYQUERY \
  NS_IMETHOD DoQuery(nsIAbDirectoryQueryArguments *arguments, nsIAbDirectoryQueryResultListener *listener, PRInt32 resultLimit, PRInt32 timeOut, PRInt32 *_retval); \
  NS_IMETHOD StopQuery(PRInt32 contextID); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYQUERY(_to) \
  NS_IMETHOD DoQuery(nsIAbDirectoryQueryArguments *arguments, nsIAbDirectoryQueryResultListener *listener, PRInt32 resultLimit, PRInt32 timeOut, PRInt32 *_retval) { return _to DoQuery(arguments, listener, resultLimit, timeOut, _retval); } \
  NS_IMETHOD StopQuery(PRInt32 contextID) { return _to StopQuery(contextID); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYQUERY(_to) \
  NS_IMETHOD DoQuery(nsIAbDirectoryQueryArguments *arguments, nsIAbDirectoryQueryResultListener *listener, PRInt32 resultLimit, PRInt32 timeOut, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoQuery(arguments, listener, resultLimit, timeOut, _retval); } \
  NS_IMETHOD StopQuery(PRInt32 contextID) { return !_to ? NS_ERROR_NULL_POINTER : _to->StopQuery(contextID); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryQuery : public nsIAbDirectoryQuery
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYQUERY

  nsAbDirectoryQuery();

private:
  ~nsAbDirectoryQuery();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryQuery, nsIAbDirectoryQuery)

nsAbDirectoryQuery::nsAbDirectoryQuery()
{
  /* member initializers and constructor code */
}

nsAbDirectoryQuery::~nsAbDirectoryQuery()
{
  /* destructor code */
}

/* long doQuery (in nsIAbDirectoryQueryArguments arguments, in nsIAbDirectoryQueryResultListener listener, in long resultLimit, in long timeOut); */
NS_IMETHODIMP nsAbDirectoryQuery::DoQuery(nsIAbDirectoryQueryArguments *arguments, nsIAbDirectoryQueryResultListener *listener, PRInt32 resultLimit, PRInt32 timeOut, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void stopQuery (in long contextID); */
NS_IMETHODIMP nsAbDirectoryQuery::StopQuery(PRInt32 contextID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirectoryQuery_h__ */
