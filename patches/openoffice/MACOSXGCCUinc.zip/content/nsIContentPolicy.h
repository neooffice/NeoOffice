/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIContentPolicy.idl
 */

#ifndef __gen_nsIContentPolicy_h__
#define __gen_nsIContentPolicy_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindow; /* forward declaration */

class nsIURI; /* forward declaration */


/* starting interface:    nsIContentPolicy */
#define NS_ICONTENTPOLICY_IID_STR "1cb4085d-5407-4169-bcfe-4c5ba013fa5b"

#define NS_ICONTENTPOLICY_IID \
  {0x1cb4085d, 0x5407, 0x4169, \
    { 0xbc, 0xfe, 0x4c, 0x5b, 0xa0, 0x13, 0xfa, 0x5b }}

/**
 * Interface for content policy mechanism.  Implementations of this
 * interface can be used to control loading of various types of out-of-line
 * content, or processing of certain types of in-line content.
 */
class NS_NO_VTABLE nsIContentPolicy : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICONTENTPOLICY_IID)

  enum { OTHER = 0 };

  enum { SCRIPT = 1 };

  enum { IMAGE = 2 };

  enum { STYLESHEET = 3 };

  enum { OBJECT = 4 };

  enum { SUBDOCUMENT = 5 };

  enum { CONTROL_TAG = 6 };

  enum { RAW_URL = 7 };

  enum { DOCUMENT = 8 };

  /**
   * Should the content at this location be loaded and processed?
   *
   */
  /* boolean shouldLoad (in PRInt32 contentType, in nsIURI contentLocation, in nsISupports ctxt, in nsIDOMWindow window); */
  NS_IMETHOD ShouldLoad(PRInt32 contentType, nsIURI *contentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) = 0;

  /**
   * Should the contents of the element in question be processed?
   */
  /* boolean shouldProcess (in PRInt32 contentType, in nsIURI documentLocation, in nsISupports ctxt, in nsIDOMWindow window); */
  NS_IMETHOD ShouldProcess(PRInt32 contentType, nsIURI *documentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICONTENTPOLICY \
  NS_IMETHOD ShouldLoad(PRInt32 contentType, nsIURI *contentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval); \
  NS_IMETHOD ShouldProcess(PRInt32 contentType, nsIURI *documentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICONTENTPOLICY(_to) \
  NS_IMETHOD ShouldLoad(PRInt32 contentType, nsIURI *contentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) { return _to ShouldLoad(contentType, contentLocation, ctxt, window, _retval); } \
  NS_IMETHOD ShouldProcess(PRInt32 contentType, nsIURI *documentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) { return _to ShouldProcess(contentType, documentLocation, ctxt, window, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICONTENTPOLICY(_to) \
  NS_IMETHOD ShouldLoad(PRInt32 contentType, nsIURI *contentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ShouldLoad(contentType, contentLocation, ctxt, window, _retval); } \
  NS_IMETHOD ShouldProcess(PRInt32 contentType, nsIURI *documentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ShouldProcess(contentType, documentLocation, ctxt, window, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsContentPolicy : public nsIContentPolicy
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICONTENTPOLICY

  nsContentPolicy();

private:
  ~nsContentPolicy();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsContentPolicy, nsIContentPolicy)

nsContentPolicy::nsContentPolicy()
{
  /* member initializers and constructor code */
}

nsContentPolicy::~nsContentPolicy()
{
  /* destructor code */
}

/* boolean shouldLoad (in PRInt32 contentType, in nsIURI contentLocation, in nsISupports ctxt, in nsIDOMWindow window); */
NS_IMETHODIMP nsContentPolicy::ShouldLoad(PRInt32 contentType, nsIURI *contentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean shouldProcess (in PRInt32 contentType, in nsIURI documentLocation, in nsISupports ctxt, in nsIDOMWindow window); */
NS_IMETHODIMP nsContentPolicy::ShouldProcess(PRInt32 contentType, nsIURI *documentLocation, nsISupports *ctxt, nsIDOMWindow *window, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIContentPolicy_h__ */
