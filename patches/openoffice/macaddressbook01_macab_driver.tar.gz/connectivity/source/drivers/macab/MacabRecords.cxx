/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: MacabRecords.cxx,v $
 *
 *  $Revision: 0.1 $
 *
 *  last change: $Author: cremlae $ $Date: 2007/07/07 01:01:33 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2005 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

// MARKER(update_precomp.py): autogen include statement, do not remove
#include "precompiled_connectivity.hxx"

#include "MacabRecords.hxx"

#ifndef _CONNECTIVITY_MACAB_RECORD_HXX_
#include "MacabRecord.hxx"
#endif

#ifndef _CONNECTIVITY_MACAB_HEADER_HXX_
#include "MacabHeader.hxx"
#endif

#ifndef _CONNECTIVITY_MACAB_UTILITIES_HXX_
#include "macabutilities.hxx"
#endif

#include <Carbon/Carbon.h>
#include <AddressBook/ABAddressBookC.h>

#ifndef _COM_SUN_STAR_UTIL_DATETIME_HPP_
#include <com/sun/star/util/DateTime.hpp>
#endif

using namespace connectivity::macab;
using namespace com::sun::star::util;

// -------------------------------------------------------------------------
MacabRecords::MacabRecords(const ABAddressBookRef _addressBook, MacabHeader *_header, MacabRecord **_records, sal_Int32 _numRecords)
{
	header = _header;
	recordsSize = _numRecords;
	currentRecord = _numRecords;
	records = _records;
	addressBook = _addressBook;
	recordType = kABPersonRecordType;
	bootstrap_CF_types();
}

// -------------------------------------------------------------------------
MacabRecords::MacabRecords(const MacabRecords *_copy)
{
	recordsSize = _copy->recordsSize;
	addressBook = _copy->addressBook;
	m_sName = _copy->m_sName;

	currentRecord = 0;
	header = NULL;
	records = new MacabRecord *[recordsSize];
	recordType = kABPersonRecordType;

	bootstrap_CF_types();
}

// -------------------------------------------------------------------------
MacabRecords::MacabRecords(const ABAddressBookRef _addressBook)
{
	recordsSize = 0;
	currentRecord = 0;
	records = NULL;
	header = NULL;
	addressBook = _addressBook;
	recordType = kABPersonRecordType;
	bootstrap_CF_types();
}

// -------------------------------------------------------------------------
void MacabRecords::initialize()
{
	if(records != NULL)
	{
		sal_Int32 i;

		for(i = 0; i < recordsSize; i++)
			delete records[i];

		delete [] records;
	}

	if(header != NULL)
		delete header;

	CFArrayRef allRecords;
	if(CFStringCompare(recordType, kABPersonRecordType, 0) == kCFCompareEqualTo)
		allRecords = ABCopyArrayOfAllPeople(addressBook);
	else
		allRecords = ABCopyArrayOfAllGroups(addressBook);

	ABRecordRef record;
	sal_Int32 i;
	recordsSize = (sal_Int32) CFArrayGetCount(allRecords);
	records = new MacabRecord *[recordsSize];

	header = createHeaderForRecordType(allRecords, recordType);
	header->sortRecord();

	for(i = 0; i < recordsSize; i++)
	{
		record = (ABRecordRef) CFArrayGetValueAtIndex(allRecords, i);
		records[i] = createMacabRecord(record, header, recordType);
	}
	currentRecord = recordsSize;
	
	CFRelease(allRecords);
}

// -------------------------------------------------------------------------
MacabRecords::~MacabRecords()
{
}

// -------------------------------------------------------------------------
void MacabRecords::setHeader(MacabHeader *_header)
{
	if(header != NULL)
		delete header;
	header = _header;
}

// -------------------------------------------------------------------------
MacabHeader *MacabRecords::getHeader() const
{
	return header;
}

// -------------------------------------------------------------------------
MacabRecord *MacabRecords::insertRecord(MacabRecord *_newRecord, const sal_Int32 _location)
{
	MacabRecord *oldRecord;
	if(_location >= recordsSize)
	{
		sal_Int32 i;
		MacabRecord **newRecordsArray = new MacabRecord *[_location+1];
		for(i = 0; i < recordsSize; i++)
		{
			newRecordsArray[i] = records[i];
		}
		records = newRecordsArray;
	}

	if(_location >= currentRecord)
		currentRecord = _location+1;
	
	oldRecord = records[_location];
	records[_location] = _newRecord;
	return oldRecord;
}

// -------------------------------------------------------------------------
void MacabRecords::insertRecord(MacabRecord *_newRecord)
{
	insertRecord(_newRecord, currentRecord);
}

// -------------------------------------------------------------------------
MacabRecord *MacabRecords::getRecord(const sal_Int32 _location) const
{
	if(_location >= recordsSize)
		return NULL;
	return records[_location];
}

// -------------------------------------------------------------------------
macabfield *MacabRecords::getField(const sal_Int32 _recordNumber, const sal_Int32 _columnNumber) const
{
	if(_recordNumber >= recordsSize)
		return NULL;

	MacabRecord *record = records[_recordNumber];

	if(_columnNumber >= record->getSize())
		return NULL;

	return record->get(_columnNumber);
}

// -------------------------------------------------------------------------
macabfield *MacabRecords::getField(const sal_Int32 _recordNumber, const ::rtl::OUString _columnName) const
{
	if(header != NULL)
	{
		sal_Int32 columnNumber = header->getColumnNumber(_columnName);
		if(columnNumber == -1)
			return NULL;

		return getField(_recordNumber, columnNumber);
	}
	else
	{
		// error: shouldn't access field with null header!
		return NULL;
	}
}

// -------------------------------------------------------------------------
sal_Int32 MacabRecords::getFieldNumber(const ::rtl::OUString _columnName) const
{
	if(header != NULL)
		return header->getColumnNumber(_columnName);
	else
		// error: shouldn't access field with null header!
		return -1;
}

// -------------------------------------------------------------------------
/* Create the lcl_CFTypes array -- we need this because there is no
 * way to get the ABType of an object from the object itself, and the
 * function ABTypeOfProperty can't handle multiple levels of data
 * (e.g., it can tell us that "address" is of type
 * kABDictionaryProperty, but it cannot tell us that all of the keys
 * and values in the dictionary have type kABStringProperty. On the
 * other hand, we _can_ get the CFType out of any object.
 * Unfortunately, all information about CFTypeIDs comes with the
 * warning that they change between releases, so we build them
 * ourselves here. (The one that we can't build is for multivalues,
 * e.g., kABMultiStringProperty. All of these appear to have the
 * same type: 1, but there is no function that I've found to give
 * us that dynamically in case that number ever changes.
 */
void MacabRecords::bootstrap_CF_types()
{
	lcl_CFTypesLength = 6;
	lcl_CFTypes = new lcl_CFType[lcl_CFTypesLength];

	lcl_CFTypes[0].cf = CFNumberGetTypeID();
	lcl_CFTypes[0].ab = kABIntegerProperty;

	lcl_CFTypes[1].cf = CFStringGetTypeID();
	lcl_CFTypes[1].ab = kABStringProperty;

	lcl_CFTypes[2].cf = CFDateGetTypeID();
	lcl_CFTypes[2].ab = kABDateProperty;

	lcl_CFTypes[3].cf = CFArrayGetTypeID();
	lcl_CFTypes[3].ab = kABArrayProperty;

	lcl_CFTypes[4].cf = CFDictionaryGetTypeID();
	lcl_CFTypes[4].ab = kABDictionaryProperty;

	lcl_CFTypes[5].cf = CFDataGetTypeID();
	lcl_CFTypes[5].ab = kABDataProperty;
}

// -------------------------------------------------------------------------
MacabHeader *MacabRecords::createHeaderForRecordType(const CFArrayRef _records, const CFStringRef _recordType) const
{
	CFArrayRef recordProperties = ABCopyArrayOfPropertiesForRecordType(addressBook, _recordType);
	ABRecordRef record;
	sal_Int32 numRecords = (sal_Int32) CFArrayGetCount(_records);
	sal_Int32 numProperties = (sal_Int32) CFArrayGetCount(recordProperties); 
	sal_Int32 i, j;
	CFStringRef property;
	MacabHeader *headerDataForProperty;
	MacabHeader *lcl_header = new MacabHeader();

	/* Go through the array... */
	for(i = 0; i < numRecords; i++)
	{
		/* This is the record */
		record = (ABRecordRef) CFArrayGetValueAtIndex(_records, i);

		/* Go through the properties array... */
		for(j = 0; j < numProperties; j++)
		{
			/* Get the Property's string name */
			property = (CFStringRef) CFArrayGetValueAtIndex(recordProperties, j);
			headerDataForProperty = createHeaderForProperty(record,property,_recordType);
			if(headerDataForProperty != NULL)
			{
				(*lcl_header) += headerDataForProperty;
				delete headerDataForProperty;
			}
		}

	} // end of for loop through records

	CFRelease(recordProperties);

	return lcl_header;
}

// -------------------------------------------------------------------------
MacabHeader *MacabRecords::createHeaderForProperty(const ABRecordRef _record, const CFStringRef _propertyName, const CFStringRef _recordType) const
{
	// local variables
	CFTypeRef propertyValue;
	ABPropertyType propertyType;
	MacabHeader *result;

	/* Get the property's value */
	propertyValue = ABRecordCopyValue(_record,_propertyName);
	if(propertyValue == NULL)
		return NULL;

	propertyType = ABTypeOfProperty(addressBook, _recordType, _propertyName);
	
	result = createHeaderForProperty(propertyType, propertyValue, _propertyName);
	CFRelease(propertyValue);
	return result;
}

// -------------------------------------------------------------------------
MacabHeader *MacabRecords::createHeaderForProperty(const ABPropertyType _propertyType, const CFTypeRef _propertyValue, const CFStringRef _propertyName) const
{
	macabfield **headerNames = NULL;
	sal_Int32 length = 0;

	switch(_propertyType)
	{
		case kABStringProperty:
		case kABRealProperty:
		case kABIntegerProperty:
		case kABDateProperty:
			length = 1;
			headerNames = new macabfield *[1];
			headerNames[0] = new macabfield;
			headerNames[0]->value = _propertyName;
			headerNames[0]->type = _propertyType;
			break;

		case kABMultiIntegerProperty:
		case kABMultiDateProperty:
		case kABMultiStringProperty:
		case kABMultiRealProperty:
		case kABMultiDataProperty:
			{
			sal_Int32 i;
			sal_Int32 multiLength = ABMultiValueCount((ABMutableMultiValueRef) _propertyValue);
			CFStringRef multiLabel;
			::rtl::OUString multiLabelString;
			::rtl::OUString multiPropertyString;
			::rtl::OUString headerNameString;
			ABPropertyType multiType = (ABPropertyType) (ABMultiValuePropertyType((ABMutableMultiValueRef) _propertyValue) - 0x100);

			length = multiLength;
			headerNames = new macabfield *[multiLength];
			multiPropertyString = CFStringToOUString(_propertyName);

			/* Go through each entry... */
			for(i = 0; i < multiLength; i++)
			{
				/* label */
				multiLabel = ABMultiValueCopyLabelAtIndex((ABMutableMultiValueRef) _propertyValue, i);
				multiLabelString = CFStringToOUString(multiLabel);
				CFRelease(multiLabel);
				headerNameString = multiPropertyString + ::rtl::OUString::createFromAscii(": ") + fixLabel(multiLabelString);
				headerNames[i] = new macabfield;
				headerNames[i]->value = OUStringToCFString(headerNameString);
				headerNames[i]->type = multiType;
			}
			}
			break;

		case kABMultiArrayProperty:
		case kABMultiDictionaryProperty:
			{
				sal_Int32 i,j,k;
				sal_Int32 multiLengthFirstLevel = ABMultiValueCount((ABMutableMultiValueRef) _propertyValue);
				sal_Int32 multiLengthSecondLevel = 0;
				CFStringRef multiLabel;
				CFTypeRef multiValue;
				::rtl::OUString multiLabelString;
				::rtl::OUString multiPropertyString;
				MacabHeader **multiHeaders = new MacabHeader *[multiLengthFirstLevel];
				ABPropertyType multiType = (ABPropertyType) (ABMultiValuePropertyType((ABMutableMultiValueRef) _propertyValue) - 0x100);

				multiPropertyString = CFStringToOUString(_propertyName);

				/* Go through each entry... */
				for(i = 0; i < multiLengthFirstLevel; i++)
				{
					/* label */
					multiLabel = ABMultiValueCopyLabelAtIndex((ABMutableMultiValueRef) _propertyValue, i);
					multiValue = ABMultiValueCopyValueAtIndex((ABMutableMultiValueRef) _propertyValue, i);
					if(multiValue && multiLabel)
					{
						multiLabelString = multiPropertyString + ::rtl::OUString::createFromAscii(": ") + fixLabel(CFStringToOUString(multiLabel));
						CFRelease(multiLabel);
						multiLabel = OUStringToCFString(multiLabelString);
						multiHeaders[i] = createHeaderForProperty(multiType, multiValue, multiLabel);
						multiLengthSecondLevel += multiHeaders[i]->getSize();
					}
					else
					{
						multiHeaders[i] = new MacabHeader();
					}
					if(multiValue)
						CFRelease(multiValue);
				}

				length = multiLengthSecondLevel;
				headerNames = new macabfield *[multiLengthSecondLevel];

				for(i = 0, j = 0, k = 0; i < multiLengthSecondLevel; i++,k++)
				{
					while(multiHeaders[j]->getSize() == k)
					{
						j++;
						k = 0;
					}
					
					headerNames[i] = multiHeaders[j]->copy(k);
				}
				for(i = 0; i < multiLengthFirstLevel; i++)
					delete multiHeaders[i];

				delete [] multiHeaders;
			}
			break;
			
		case kABDictionaryProperty:
			{
			/* Assume all keys are strings */
			sal_Int32 numRecords = (sal_Int32) CFDictionaryGetCount((CFDictionaryRef) _propertyValue);
			CFStringRef *dictKeys;
			CFTypeRef *dictValues;
			::rtl::OUString dictKeyString, propertyNameString;
			ABPropertyType dictType;
			sal_Int32 i,j,k;
			MacabHeader **dictHeaders = new MacabHeader *[numRecords];
			::rtl::OUString dictLabelString;
			CFStringRef dictLabel;

			dictKeys = (CFStringRef *) malloc(sizeof(CFStringRef)*numRecords);
			dictValues = (CFTypeRef *) malloc(sizeof(CFTypeRef)*numRecords);

			CFDictionaryGetKeysAndValues((CFDictionaryRef) _propertyValue, (const void **) dictKeys, (const void **) dictValues);

			propertyNameString = CFStringToOUString(_propertyName);

			length = 0;
			for(i = 0; i < numRecords; i++)
			{
				dictType = (ABPropertyType) getABTypeFromCFType( CFGetTypeID(dictValues[i]) );
				dictKeyString = CFStringToOUString(dictKeys[i]);
				dictLabelString = propertyNameString + ::rtl::OUString::createFromAscii(": ") + fixLabel(dictKeyString);
				dictLabel = OUStringToCFString(dictLabelString);
				dictHeaders[i] = createHeaderForProperty(dictType, dictValues[i], dictLabel);
				length += dictHeaders[i]->getSize();
				CFRelease(dictLabel);
			}

			headerNames = new macabfield *[length];
			for(i = 0, j = 0, k = 0; i < length; i++,k++)
			{
				while(dictHeaders[j]->getSize() == k)
				{
					j++;
					k = 0;
				}
				
				headerNames[i] = dictHeaders[j]->copy(k);
			}

			for(i = 0; i < numRecords; i++)
				delete dictHeaders[i];

			delete [] dictHeaders;
			free(dictKeys);
			free(dictValues);
			}
			break;

		case kABArrayProperty:
			{
				sal_Int32 arrLength = (sal_Int32) CFArrayGetCount( (CFArrayRef) _propertyValue);
				sal_Int32 i,j,k;
				CFTypeRef arrValue;
				ABPropertyType arrType;
				MacabHeader **arrHeaders = new MacabHeader *[arrLength];
				::rtl::OUString propertyNameString = CFStringToOUString(_propertyName);
				::rtl::OUString arrLabelString;
				CFStringRef arrLabel;

				length = 0;
				for(i = 0; i < arrLength; i++)
				{
					arrValue = (CFTypeRef) CFArrayGetValueAtIndex( (CFArrayRef) _propertyValue, i);
					arrType = (ABPropertyType) getABTypeFromCFType( CFGetTypeID(arrValue) );
					arrLabelString = propertyNameString + ::rtl::OUString::valueOf(i);
					arrLabel = OUStringToCFString(arrLabelString);
					arrHeaders[i] = createHeaderForProperty(arrType, arrValue, arrLabel);
					length += arrHeaders[i]->getSize();
					CFRelease(arrLabel);
				}

				headerNames = new macabfield *[length];
				for(i = 0, j = 0, k = 0; i < length; i++,k++)
				{
					while(arrHeaders[j]->getSize() == k)
					{
						j++;
						k = 0;
					}
					
					headerNames[i] = arrHeaders[j]->copy(k);
				}
				for(i = 0; i < arrLength; i++)
					delete arrHeaders[i];

				delete [] arrHeaders;
			}
			break;

			default:
				break;

	}
	if(length != 0)
	{
		manageDuplicateHeaders(headerNames, length);
		MacabHeader *headerResult = new MacabHeader(length, headerNames);
		delete [] headerNames;
		return headerResult;
	}
	else
		return NULL;
}

// -------------------------------------------------------------------------
void MacabRecords::manageDuplicateHeaders(macabfield **_headerNames, const sal_Int32 _length) const
{
	/* If we have two cases of, say, phone: home, this makes it:
	 * phone: home (1)
	 * phone: home (2)
	 */
	sal_Int32 i, j;
	sal_Int32 count;
	for(i = _length-1; i >= 0; i--)
	{
		count = 1;
		for( j = i-1; j >= 0; j--)
		{
			if(CFEqual(_headerNames[i]->value, _headerNames[j]->value))
			{
				count++;
			}
		}

		// duplicate!
		if(count != 1)
		{
			// There is probably a better way to do this...
			::rtl::OUString newName = CFStringToOUString((CFStringRef) _headerNames[i]->value);
			CFRelease(_headerNames[i]->value);
			newName += ::rtl::OUString::createFromAscii(" (") + ::rtl::OUString::valueOf(count) + ::rtl::OUString::createFromAscii(")");
			_headerNames[i]->value = OUStringToCFString(newName);
		}
	}
}

// -------------------------------------------------------------------------
MacabRecord *MacabRecords::createMacabRecord(const ABRecordRef _abrecord, const MacabHeader *_header, const CFStringRef _recordType) const
{
	MacabRecord *macabRecord = new MacabRecord(_header->getSize());
	sal_Int32 i;
	CFArrayRef recordProperties = ABCopyArrayOfPropertiesForRecordType(addressBook, _recordType);
	sal_Int32 numProperties = (sal_Int32) CFArrayGetCount(recordProperties); 
	CFStringRef propertyName;
	::rtl::OUString propertyNameString;
	CFTypeRef propertyValue;
	ABPropertyType propertyType;
	for(i = 0; i < numProperties; i++)
	{
		propertyName = (CFStringRef) CFArrayGetValueAtIndex(recordProperties, i);
		propertyNameString = CFStringToOUString(propertyName);

		/* Get the property's value */
		propertyValue = ABRecordCopyValue(_abrecord,propertyName);
		if(propertyValue != NULL)
		{
			propertyType = ABTypeOfProperty(addressBook, _recordType, propertyName);
			if(propertyType != kABErrorInProperty)
				insertPropertyIntoMacabRecord(propertyType, macabRecord, _header, propertyNameString, propertyValue);

			CFRelease(propertyValue);
		}
	}
	CFRelease(recordProperties);
	return macabRecord;
}

// -------------------------------------------------------------------------
void MacabRecords::insertPropertyIntoMacabRecord(MacabRecord *_abrecord, const MacabHeader *_header, const ::rtl::OUString _propertyName, const CFTypeRef _propertyValue) const
{
	CFTypeID cf_type = CFGetTypeID(_propertyValue);
	ABPropertyType ab_type = getABTypeFromCFType( cf_type );

	if(ab_type != kABErrorInProperty)
		insertPropertyIntoMacabRecord(ab_type, _abrecord, _header, _propertyName, _propertyValue);
}

// -------------------------------------------------------------------------
void MacabRecords::insertPropertyIntoMacabRecord(const ABPropertyType _propertyType, MacabRecord *_abrecord, const MacabHeader *_header, const ::rtl::OUString _propertyName, const CFTypeRef _propertyValue) const
{
	// local variables

	/* If there is no value, return */
	if(_propertyValue == NULL)
		return;

	/* The main switch statement */
	switch(_propertyType)
	{
		case kABStringProperty:
		case kABRealProperty:
		case kABIntegerProperty:
		case kABDateProperty:
		{
			sal_Bool bPlaced = sal_False;
			::rtl::OUString columnName = ::rtl::OUString(_propertyName);
			sal_Int32 i = 1;
			
			// A big safeguard to prevent two fields from having the same name.
			while(bPlaced != sal_True)
			{
				sal_Int32 columnNumber = _header->getColumnNumber(columnName);
				bPlaced = sal_True;
				if(columnNumber != -1)
				{
					// collision!
					if(_abrecord->get(columnNumber) != NULL)
					{
						bPlaced = sal_False;
						i++;
						columnName = ::rtl::OUString(_propertyName) + ::rtl::OUString::createFromAscii(" (") + ::rtl::OUString::valueOf(i) + ::rtl::OUString::createFromAscii(")");
					}
					else
					{
						_abrecord->insertAtColumn(_propertyValue, _propertyType, columnNumber);
					}
				}
			}
		}
		break;

		/* Array */
		case kABArrayProperty:
			{
				/* An array is basically just a list of anything, so all we do
				 * is go through the array, and get the string representation
				 * of each element, and list them in a string, separated by
				 * commas.
				 */
				sal_Int32 arrLength = (sal_Int32) CFArrayGetCount( (CFArrayRef) _propertyValue);
				sal_Int32 i;
				const void *arrValue;
				::rtl::OUString newPropertyName;

				/* Going through the array... */
				for(i = 0; i < arrLength; i++)
				{
					/* Get the value */
					arrValue = CFArrayGetValueAtIndex( (CFArrayRef) _propertyValue, i);
					newPropertyName = _propertyName + ::rtl::OUString::valueOf(i);
					insertPropertyIntoMacabRecord(_abrecord, _header, newPropertyName, arrValue);
					CFRelease(arrValue);
				}

			} // end of block for the case of array type
			break;

		/* Dictionary */
		case kABDictionaryProperty:
			{
				/* A dictionary is basically a hashmap. Technically, it can
				 * hold any object as a key and any object as a value.
				 * Traditionally, as far as I can tell, the key and value are
				 * both strings, but (to be safe) we don't assume that and
				 * run the version of getStringRepresentationOfPropertyValue
				 * that tries to find the type on its own on each key and
				 * each value.
				 */

				sal_Int32 numRecords = (sal_Int32) CFDictionaryGetCount((CFDictionaryRef) _propertyValue);
				CFStringRef *dictKeys;
				CFTypeRef *dictValues;
				::rtl::OUString dictKeyString;
				sal_Int32 i;
				::rtl::OUString newPropertyName;

				dictKeys = (CFStringRef *) malloc(sizeof(CFStringRef)*numRecords);
				dictValues = (CFTypeRef *) malloc(sizeof(CFTypeRef)*numRecords);

				CFDictionaryGetKeysAndValues((CFDictionaryRef) _propertyValue, (const void **) dictKeys, (const void **) dictValues);


				/* Going through the dictionary... */
				for(i = 0; i < numRecords; i++)
				{
					/* Get the value */
					dictKeyString = CFStringToOUString(dictKeys[i]);
					newPropertyName = _propertyName + ::rtl::OUString::createFromAscii(": ") + fixLabel(dictKeyString);
					insertPropertyIntoMacabRecord(_abrecord, _header, newPropertyName, dictValues[i]);
				}

				free(dictKeys);
				free(dictValues);
			} // end of block for the case of dictionary type
			break;

		/* Multivalue */
		case kABMultiIntegerProperty:
		case kABMultiDateProperty:
		case kABMultiStringProperty:
		case kABMultiRealProperty:
		case kABMultiDataProperty:
		case kABMultiDictionaryProperty:
		case kABMultiArrayProperty:

			{
				/* All scalar multivalues are handled in the same way. Each entry is
				 * a label and a value. All labels are strings
				 * (kABStringProperty), and all values have the same type
				 * (which is the type of the multivalue minus 255, or as
				 * Carbon's list of property types has it, minux 0x100.
				 * We just get the correct type, then go through each entry
				 * and get the label and value and print them in a list.
				 */

				/* variables local to this block */
				sal_Int32 i;
				sal_Int32 multiLength = ABMultiValueCount((ABMutableMultiValueRef) _propertyValue);
				CFStringRef multiLabel;
				CFTypeRef multiValue;
				::rtl::OUString multiLabelString, newPropertyName;
				ABPropertyType multiType = (ABPropertyType) (ABMultiValuePropertyType((ABMutableMultiValueRef) _propertyValue) - 0x100);

				/* Go through each entry... */
				for(i = 0; i < multiLength; i++)
				{
					/* Label and value */
					multiLabel = ABMultiValueCopyLabelAtIndex((ABMutableMultiValueRef) _propertyValue, i);
					multiValue = ABMultiValueCopyValueAtIndex((ABMutableMultiValueRef) _propertyValue, i);

					multiLabelString = CFStringToOUString(multiLabel);
					newPropertyName = _propertyName + ::rtl::OUString::createFromAscii(": ") + fixLabel(multiLabelString);
					insertPropertyIntoMacabRecord(multiType, _abrecord, _header, newPropertyName, multiValue);

					/* free our variables */
					CFRelease(multiLabel);
					CFRelease(multiValue);
				} // end of loop through each entry
			} // end of block for the case of multivalue types
			break;

		/* Unhandled types */
		case kABErrorInProperty:
		case kABDataProperty:
		default:
			/* An error, as far as I have seen, only shows up as a type
			 * returned by a function for dictionaries when the dictionary
			 * holds many types of values. Since we do not use that function,
			 * it shouldn't come up. I have yet to see the kABDataProperty,
			 * and I am not sure how to represent it as a string anyway,
			 * since it appears to just be a bunch of bytes. Assumably, if
			 * these bytes made up a string, the type would be
			 * kABStringProperty. I think that this is used when we are not
			 * sure what the type is (e.g., it could be a string or a number).
			 * That being the case, I still don't know how to represent it.
			 * And, default should never come up, since we've exhausted all
			 * of the possible types for ABPropertyType, but... just in case.
			 */
			break;
	}

}

// -------------------------------------------------------------------------
ABPropertyType MacabRecords::getABTypeFromCFType(const CFTypeID cf_type ) const
{
	sal_Int32 i;
	for(i = 0; i < lcl_CFTypesLength; i++)
	{
		/* A match! */
		if(lcl_CFTypes[i].cf == (sal_Int32) cf_type)
		{
			return (ABPropertyType) lcl_CFTypes[i].ab;
		}
	}
	return kABErrorInProperty;
}

// -------------------------------------------------------------------------
sal_Int32 MacabRecords::size() const
{
	return currentRecord;
}

// -------------------------------------------------------------------------
MacabRecords *MacabRecords::begin()
{
	return this;
}

// -------------------------------------------------------------------------
MacabRecords::iterator::iterator ()
{
}

// -------------------------------------------------------------------------
MacabRecords::iterator::~iterator ()
{
}

// -------------------------------------------------------------------------
void MacabRecords::iterator::operator= (MacabRecords *_records)
{
	id = 0;
	records = _records;
}

// -------------------------------------------------------------------------
void MacabRecords::iterator::operator++ ()
{
	id++;
}

// -------------------------------------------------------------------------
sal_Bool MacabRecords::iterator::operator!= (const sal_Int32 i) const
{
	return(id != i);
}

// -------------------------------------------------------------------------
sal_Bool MacabRecords::iterator::operator== (const sal_Int32 i) const
{
	return(id == i);
}

// -------------------------------------------------------------------------
MacabRecord *MacabRecords::iterator::operator* () const
{
	return records->getRecord(id);
}

// -------------------------------------------------------------------------
sal_Int32 MacabRecords::end() const
{
	return currentRecord;
}

// -------------------------------------------------------------------------
void MacabRecords::swap(const sal_Int32 _id1, const sal_Int32 _id2)
{
	MacabRecord *swapRecord = records[_id1];

	records[_id1] = records[_id2];
	records[_id2] = swapRecord;
}

// -------------------------------------------------------------------------
void MacabRecords::setName(const ::rtl::OUString _sName)
{
	m_sName = _sName;
}

// -------------------------------------------------------------------------
::rtl::OUString MacabRecords::getName() const
{
	return m_sName;
}

