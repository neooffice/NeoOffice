/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: MacabHeader.cxx,v $
 *
 *  $Revision: 0.1 $
 *
 *  last change: $Author: cremlae $ $Date: 2007/07/07 01:01:33 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2005 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

// MARKER(update_precomp.py): autogen include statement, do not remove
#include "precompiled_connectivity.hxx"

#include "MacabHeader.hxx"

#ifndef _CONNECTIVITY_MACAB_RECORD_HXX_
#include "MacabRecord.hxx"
#endif

#ifndef _CONNECTIVITY_MACAB_UTILITIES_HXX_
#include "macabutilities.hxx"
#endif

#include <math.h>

#ifndef _COM_SUN_STAR_SDBC_DATATYPE_HPP_
#include <com/sun/star/sdbc/DataType.hpp>
#endif

using namespace connectivity::macab;
using namespace com::sun::star::sdbc;

// -------------------------------------------------------------------------
MacabHeader::MacabHeader(const sal_Int32 _size, macabfield **_fields)
{
	sal_Int32 i;
	size = _size;
	fields = new macabfield *[size];
	for(i = 0; i < size; i++)
	{
		if(_fields[i] == NULL)
		{
			fields[i] = NULL;
		}
		else
		{
			fields[i] = new macabfield;
			fields[i]->type = _fields[i]->type;
			fields[i]->value = _fields[i]->value;
			CFRetain(fields[i]->value);
		}
	}
	
}

// -------------------------------------------------------------------------
MacabHeader::MacabHeader()
{
	size = 0;
	fields = NULL;
}

// -------------------------------------------------------------------------
MacabHeader::~MacabHeader()
{
}

// -------------------------------------------------------------------------
void MacabHeader::operator+= (const MacabHeader *r)
{
	sal_Int32 rSize = r->getSize();
	if(rSize != 0)
	{
		if(size == 0)
		{
			sal_Int32 i;
			size = rSize;
			fields = new macabfield *[size];
			for(i = 0; i < size; i++)
			{
				fields[i] = r->copy(i);
			}
		}
		else
		{
			sal_Int32 i;
			sal_Int32 numToAdd = 0, numAdded = 0;
			macabfield **newFields;
			for( i = 0; i < rSize; i++)
			{
				if(!contains(r->get(i)))
				{
					numToAdd++;
				}
			}
			
			newFields = new macabfield *[size+numToAdd];
			for(i = 0; i < size; i++)
			{
				newFields[i] = copy(i);
			}

			for( i = 0; i < rSize; i++)
			{
				if(!contains(r->get(i)))
				{
					newFields[size+numAdded] = r->copy(i);
					numAdded++;
					if(numAdded == numToAdd)
						break;
				}
			}

			releaseFields();
			delete [] fields;
			size += numAdded;
			fields = newFields;
		}
	}
}

// -------------------------------------------------------------------------
::rtl::OUString MacabHeader::getString(const sal_Int32 i) const
{
	::rtl::OUString nRet;

	if(i < size)
	{
		if(fields[i] == NULL)
			return ::rtl::OUString();
		try
		{
			nRet = CFStringToOUString( (CFStringRef) fields[i]->value);
		}
		catch(...){ }

	}

	return nRet;
}

// -------------------------------------------------------------------------
void MacabHeader::sortRecord()
{
	sortRecord(0,size);
}

// -------------------------------------------------------------------------
macabfield **MacabHeader::sortRecord(const sal_Int32 _start, const sal_Int32 _length)
{
	macabfield** sorted = new macabfield *[_length];
	if(_length <= 2)
	{
		if(_length == 2)
		{
			if(compareFields(fields[_start], fields[_start+1]) > 0)
			{
				sorted[0] = get(_start+1);
				sorted[1] = get(_start);
			}
			else
			{
				sorted[0] = get(_start);
				sorted[1] = get(_start+1);
			}
		}
		else if(_length == 1)
		{
			sorted[0] = get(_start);
		}
	}
	else
	{
		sal_Int32 halfLength = floor(_length/2);
		sal_Int32 fp = 0, lp = 0;
		sal_Int32 i;
		macabfield **firstHalf = new macabfield *[halfLength];
		macabfield **lastHalf = new macabfield *[_length - halfLength];

		firstHalf = sortRecord(_start, halfLength);
		lastHalf = sortRecord(_start+halfLength, _length-halfLength);
		for(i = 0; i < _length; i++)
		{
			if(compareFields(firstHalf[fp],lastHalf[lp]) < 0)
			{
				sorted[i] = firstHalf[fp++];
				if(fp == halfLength)
				{
					for( i++; i < _length; i++)
					{
						sorted[i] = lastHalf[lp++];
					}
					break;
				}
			}
			else
			{
				sorted[i] = lastHalf[lp++];
				if(lp == _length - halfLength)
				{
					for( i++; i < _length; i++)
					{
						sorted[i] = firstHalf[fp++];
					}
					break;
				}
			}
		}
		if(_length == size)
		{
			fields = sorted;
		}
	}
	return sorted;
}

// -------------------------------------------------------------------------
sal_Int32 MacabHeader::compareFields(const macabfield *_field1, const macabfield *_field2) 
{
	/* In the header, all values are of type CFStringRefs, but the type
	 * refers to the type expected for data in this column. So, we always
	 * compare strings.
	 *
	 * Also: we do the comparison in two steps. First, if both fields are
	 * from the same category (e.g., address), and at least one of them has
	 * a counter (value ends with (%d)), then we put the one with the smallest
	 * counter first (if there is no counter, that basically means that the
	 * counter is 1).
	 *
	 * Second, if there is no counter, or the two fields are from different
	 * categories, we go through a hard-coded ordering scheme, basically
	 * checking each possibility in order and returning the appropriate
	 * comparison if we find a match. (So, we first check if either field is
	 * a first name. If the first field is, it is smaller than the second,
	 * no matter what, so we return -1. If the second field is, it is smaller
	 * than the first, no matter what, so we return 1. Then, we proceed to
	 * middle name... &c. This is not a very intelligent way of doing the
	 * ordering, but I honestly could not think of a better one, given:
	 *
	 *   a) Different fields need to be compared in different ways. Single
	 *   labels (like first name, last name, &c.) can be checked for
	 *   equality (is the label equal to "first"?). Labels with multiple
	 *   parts (e.g., address) must check only the first part of the string
	 *   (e.g., does the label _start with_ "address," so that
	 *   "address: city" matches). 
	 *
	 *   b) The ordering scheme is fairly arbitrary, based on my own opinion
	 *   of what would be most useful first (names and addresses) and what
	 *   would be least useful (UIDs, creation/modification dates).
	 *
	 * If you can think of a better system, please implement it!
	 *
	 * Final note: because OUStrings are easier to work with than CFStrings,
	 * and are more powerful, we have two ways of refering to the same
	 * string: _field1->value is the CFString, while string1 is the OUString.
	 * We use the former whenever we have to (inside a Carbon function) and
	 * the latter whenever we can.
	*/
	
	if(_field1 == _field2)
		return 0;
	if(_field1 == NULL)
		return 1;
	if(_field2 == NULL)
		return -1;

	::rtl::OUString string1 = CFStringToOUString((CFStringRef) _field1->value);
	::rtl::OUString string2 = CFStringToOUString((CFStringRef) _field2->value);

	// If they start with the same word (are the same category of data), but
	// at least one has a (%d), it means that we're dealing with counters,
	// and the highest counter is always last.
	if(string1.endsWithIgnoreAsciiCaseAsciiL(")",1) )
	{
		sal_Int32 lastOpeningParen = string1.lastIndexOf('(')+1;
		::rtl::OUString sCounter1 = string1.copy(lastOpeningParen,string1.getLength()-1-lastOpeningParen);
		sal_Int32 nCounter1 = 0;

		try
		{
			nCounter1 = sCounter1.toInt32();
		}
		catch(...)
		{
			// If it wasn't a number, this label (for some reason) just
			// ends in a parenthesis.
		}

		if(nCounter1 != 0)
		{
			sal_Int32 firstSpace = string1.indexOf(' ');

			// Same category of data
			if(string2.indexOf(string1.copy(0,firstSpace)) == 0)
			{
				if(string2.endsWithIgnoreAsciiCaseAsciiL(")",1) )
				{
					lastOpeningParen = string2.lastIndexOf('(')+1;
					::rtl::OUString sCounter2 = string2.copy(lastOpeningParen,string2.getLength()-1-lastOpeningParen);
					sal_Int32 nCounter2 = 0;

					try
					{
						nCounter2 = sCounter2.toInt32();
						if(nCounter2 != 0 && nCounter1 != nCounter2)
						{
							return nCounter1 - nCounter2;
						}
					}
					catch(...)
					{
						// If it wasn't a number, this label (for some reason) just
						// ends in a parenthesis, but the first label really had a
						// number, so it must go after this one.
						return 1;
					}

				}
				else
				{
					return 1;
				}

			}
		}
	}
	else if(string2.endsWithIgnoreAsciiCaseAsciiL(")",1) )
	{
		sal_Int32 lastOpeningParen = string2.lastIndexOf('(')+1;
		::rtl::OUString sCounter2 = string2.copy(lastOpeningParen,string2.getLength()-1-lastOpeningParen);
		sal_Int32 nCounter2 = 0;

		try
		{
			nCounter2 = sCounter2.toInt32();
		}
		catch(...)
		{
			// If it wasn't a number, this label (for some reason) just
			// ends in a parenthesis
		}

		if(nCounter2 != 0)
		{
			sal_Int32 firstSpace = string1.indexOf(' ');

			// Same category of data
			if(string2.indexOf(string1.copy(0,firstSpace)) == 0)
			{
				// We know that the first string didn't have a counter, but the
				// second one does, so the second must go after the first
				return -1;
			}

		}

	}

	// Done dealing with counters...

	/* Now, we order the fields manually. The order is:
	 * first, middle, last, organization, address, phone, e-mail, <x>, ABPersonFlags, Notes, modification, creation, UID
	 * Where <x> is everything not covered by the above.
	 */

	// FIRST NAME
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABFirstNameProperty,
		0) == kCFCompareEqualTo)
			return -1;

	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABFirstNameProperty,
		0) == kCFCompareEqualTo)
			return 1;

	// MIDDLE NAME
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABMiddleNameProperty,
		0) == kCFCompareEqualTo)
			return -1;

	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABMiddleNameProperty,
		0) == kCFCompareEqualTo)
			return 1;

	// LAST NAME
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABLastNameProperty,
		0) == kCFCompareEqualTo)
			return -1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABLastNameProperty,
		0) == kCFCompareEqualTo)
			return 1;

	// ORGANIZATION
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABOrganizationProperty,
		0) == kCFCompareEqualTo)
			return -1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABOrganizationProperty,
		0) == kCFCompareEqualTo)
			return 1;
	
	// ADDRESS
	if(CFStringHasPrefix(
		(CFStringRef) _field1->value,
		kABAddressProperty) )
	{
		// If both are addresses, for now, display them in alphabetical order
		if(CFStringHasPrefix(
			(CFStringRef) _field2->value,
			kABAddressProperty) )
		{
		}

		// Otherwise, the address goes first
		else
			return -1;
	}

	// If the first is not an address and the second is, the second goes
	// first.
	else if(CFStringHasPrefix(
		(CFStringRef) _field2->value,
		kABAddressProperty) )
	{
		return 1;
	}


	// PHONE
	if(CFStringHasPrefix(
		(CFStringRef) _field1->value,
		kABPhoneProperty) )
	{
		// If both are phone numbers, for now, display them in alphabetical order
		if(CFStringHasPrefix(
			(CFStringRef) _field2->value,
			kABPhoneProperty) )
		{
		}

		// Otherwise, the phone number goes first
		else
			return -1;
	}

	// If the first is not a phone number and the second is, the second goes
	// first.
	else if(CFStringHasPrefix(
		(CFStringRef) _field2->value,
		kABPhoneProperty) )
	{
		return 1;
	}

	// EMAIL
	if(CFStringHasPrefix(
		(CFStringRef) _field1->value,
		kABEmailProperty) )
	{
		// If both are e-mail address, for now, display them in alphabetical order
		if(CFStringHasPrefix(
			(CFStringRef) _field2->value,
			kABEmailProperty) )
		{
		}

		// Otherwise, the e-mail address goes first
		else
			return -1;
	}

	// If the first is not an e-mail address and the second is, the second goes
	// first.
	else if(CFStringHasPrefix(
		(CFStringRef) _field2->value,
		kABEmailProperty) )
	{
		return 1;
	}
	
	// The following all go at the end. The order they are presented here
	// is the order in which they will appear (from the end of the list)

	::rtl::OUString sVal;

	// UID
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABUIDProperty,
		0) == kCFCompareEqualTo)
			return 1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABUIDProperty,
		0) == kCFCompareEqualTo)
			return -1;
	
	// MODIFICATION
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABModificationDateProperty,
		0) == kCFCompareEqualTo)
			return 1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABModificationDateProperty,
		0) == kCFCompareEqualTo)
			return -1;
	
	// CREATION
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABCreationDateProperty,
		0) == kCFCompareEqualTo)
			return 1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABCreationDateProperty,
		0) == kCFCompareEqualTo)
			return -1;

	// NOTE
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABNoteProperty,
		0) == kCFCompareEqualTo)
			return 1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABNoteProperty,
		0) == kCFCompareEqualTo)
			return -1;
	
	// PERSONFLAGS
	if(CFStringCompare(
		(CFStringRef) _field1->value,
		kABPersonFlags,
		0) == kCFCompareEqualTo)
			return 1;
	if(CFStringCompare(
		(CFStringRef) _field2->value,
		kABPersonFlags,
		0) == kCFCompareEqualTo)
			return -1;

	// If it wasn't one of the above, we don't have a rule for it. Compare
	// the strings using the (alphabetical) CFStringCompare function.
	CFComparisonResult result = CFStringCompare(
		(CFStringRef) _field1->value,
		(CFStringRef) _field2->value,
		0); // 0 = no options (like ignore case)

	return (sal_Int32) result;
}

// -------------------------------------------------------------------------
sal_Int32 MacabHeader::getColumnNumber(const ::rtl::OUString s) const
{
	sal_Int32 i;
	for(i = 0; i < size; i++)
	{
		if(getString(i) == s)
			break;
	}

	if(i == size)
		i = -1;

	return i;
}

// -------------------------------------------------------------------------
MacabHeader *MacabHeader::begin()
{
	return this;
}

// -------------------------------------------------------------------------
MacabHeader::iterator::iterator ()
{
}

// -------------------------------------------------------------------------
MacabHeader::iterator::~iterator ()
{
}

void MacabHeader::iterator::operator= (MacabHeader *_record)
{
	id = 0;
	record = _record;
}

// -------------------------------------------------------------------------
void MacabHeader::iterator::operator++ ()
{
	id++;
}

// -------------------------------------------------------------------------
sal_Bool MacabHeader::iterator::operator!= (const sal_Int32 i) const
{
	return(id != i);
}

// -------------------------------------------------------------------------
sal_Bool MacabHeader::iterator::operator== (const sal_Int32 i) const
{
	return(id == i);
}

// -------------------------------------------------------------------------
macabfield *MacabHeader::iterator::operator* () const
{
	return record->get(id);
}

// -------------------------------------------------------------------------
sal_Int32 MacabHeader::end() const
{
	return size;
}

