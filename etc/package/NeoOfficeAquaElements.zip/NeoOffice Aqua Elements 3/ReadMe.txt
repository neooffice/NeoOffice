NeoOffice Aqua Elements Copyright 2006-2012 Daniel Pimley.

The contents of this package is distributed under the GPL Lesser General Public License. See LICENSE for details.