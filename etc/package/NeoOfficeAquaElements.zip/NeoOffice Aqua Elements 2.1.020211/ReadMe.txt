NeoOffice Aqua Elements Copyright � 2006-2007 Daniel Pimley.

The contents of this package is distributed under the GPL General Public License. See LICENSE for details.