RetroOffice Elements Copyright � 2007-2008 Daniel Pimley.

The contents of this package is distributed under the GPL General Public License. See LICENSE for details.