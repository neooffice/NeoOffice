NeoOffice application icon (600 dpi) Copyright 2009 Daniel Pimley.

The contents of this package is distributed under the GPL Lesser General Public License. See LICENSE for details.