NeoOffice� Preferences/Toolbar Document Icons Copyright � 2006 Smokey Ardisson <alqahira@mindspring.com>

These icons are based on artwork copyright � 2006 Daniel Pimley and artwork copyright � 2004 Dan Bennett <moominpappa@ipws.com> and Smokey Ardisson <alqahira@mindspring.com>, produced under the GPL for NeoOffice.

"NeoOffice" is a registered trademark of Edward H. Peterlin.

These icons are "free software," released under the GNU General Public License v2. You may redistribute and/or modify these icons under the terms of the GNU General Public License, available at <http://www.gnu.org/licenses/gpl.txt>.

These icons are distributed in the hope that they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See "License.txt" for more details.

End-User Installation Instructions
----------------------------------

* Using Iconic:

At the moment Iconic v0.9.2 (<http://www.brettisangry.com/Iconic/> [formerly NeoIconer]), used to build custom NeoOffice icon sets, doesn't support replacing the icons that are contained within this archive.  A future version of Iconic will allow the replacement of these icons, so check the Iconic change log and instructions.  When Iconic supports replacing these icons, place these icons in the appropriate places in your favorite icon set and then follow Iconic's instructions. 


* Manually:

To install these icons, first quit NeoOffice, if it is running.

Then make a copy of NeoOffice 2.0's existing "images.zip" file.

$ cp /Applications/NeoOffice.app/Contents/share/config/images.zip ~/Desktop/images.zip

Now make the new copy writeable, so we can put the new icons in it later.

$ chmod +w ~/Desktop/images.zip

Then rename the original "images.zip" for safekeeping (this will require an administrative password).

$ sudo cp /Applications/NeoOffice.app/Contents/share/config/images.zip /Applications/NeoOffice.app/Contents/share/config/images-original.zip

Next 'cd' into the "images" folder in this package (type 'cd' followed by a space and then drag the "images" folder to the Terminal to have the path entered automatically).

$ cd /path/to/this/folder/images

Now you'll add the contents of the 3 sub-folders to the zip file on the Desktop, in the appropriate locations (the following command may appear to wrap in this document, but it should be entered--or copied-and-pasted--as one single line).

$ zip -r ~/Desktop/images.zip res/*.png; zip -r ~/Desktop/images.zip svx/res/*.png; zip -r ~/Desktop/images.zip svtools/res/*.png

Finally, move the newly-updated zip file from the Desktop back into NeoOffice (this will also require an administrative password).

$ sudo mv ~/Desktop/images.zip /Applications/NeoOffice.app/Contents/share/config/images.zip

That's it.  

To customize the other icon sets that ship with NeoOffice (Crystal, Industrial, HiContrast), simply repeat the process for those zip files (image_crysta.zip, images_industrial.zip, images_hicontrast.zip).

Finally, launch NeoOffice and look at the new NeoOffice icons appearing in various places throughout the app (in the Preferences, in the Document Properties window, in the Toolbar, in the Templates and Documents dialogue, and in the Open and Save dialogues, and perhaps others).

There are ways of doing this via the Mac OS X GUI as well, but they require more "fuss" so they have not been explained here.