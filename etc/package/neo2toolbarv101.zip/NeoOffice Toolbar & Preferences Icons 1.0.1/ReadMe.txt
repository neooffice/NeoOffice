NeoOffice� Preferences/Toolbar Document Icons Copyright � 2006 Smokey Ardisson <alqahira@ardisson.org>

These icons are based on artwork copyright � 2006 Daniel Pimley and artwork copyright � 2004 Dan Bennett <moominpappa@ipws.com> and Smokey Ardisson <alqahira@alqahira.org>.

"NeoOffice" is a registered trademark of Planamesa Inc.

The contents of this package is distributed under the GPL Lesser General Public License. See LICENSE for details.