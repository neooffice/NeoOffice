Read Me - Source

The sources for the toolbar and preferences icons in the "images" folder are the contents of the "Source" folder on the "NeoOffice Aqua Elements 1.1" disk image, the NeoOffice logo in cvs, and the files contained within this folder.

The files within this folder carry the same copyright and licensing as the files within the "images" folder; see the main ReadMe.txt and License.txt for details.