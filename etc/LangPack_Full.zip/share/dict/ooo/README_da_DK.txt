
                    Den store danske ordliste (1.4)

The Comprehensive Danish Dictionary from SSLUG. The 1.4 series of releases
contains all words from our word list, that have been verified as correct by
two or more reviewers.

You can read more about the project at:

   http://da.speling.org/

Download the latest edition of this series from:

   http://da.speling.org/filer/

----------------------------------------------------------------------------

Hvis der er fejl i ordlisten kan du rapportere det p�:

                   http://da.speling.org/fejlmelding/

----------------------------------------------------------------------------

Installation instructions (by Flemming Hjernoe <glfhj@post2.tele.dk>):

To install dictionaries in OpenOffice build OO641C to 1.0:

Unzip the dictionary files in the /OpenOffice.orgxxx/user/wordbook/ directory.

Edit the dictionary.lst file that is in that same directory using any text
editor to register a dictionary for a specific locale (the same dictionary can
be registered for multiple locales).

   tar xzf myspell-da-1.4.22.tar.gz
   cd myspell-da-1.4.22
   mv da_DK.{aff,dic} /OpenOffice.orgxxx/user/wordbook
   echo 'DICT da DK da_DK' >> /OpenOffice.orgxxx/user/wordbook/dictionary.lst

Start up OpenOffice and go to:

   Tools->Options->LanguageSettings->WritingAids
   Hit "Edit" (the upper one) and use the pull down menu to select your locale=Danish
   and then make sure to check the MySpell SpellChecker for that locale. 
   Go to Tools->Options->LanguageSettings->Languages
   Change the settings to "Danish" See note!

Your dictionary is installed and registered for Danish.

Note! OpenOffice.org1.0 danish version have a bug.
You have to change settings to "Nederlandsk" instead of "Danish".


OpenOffice.org1.0.1:

You have to copy the files to ~/OpenOffice.org1.0.1/share/dict/ooo/

