This Slovenian dictionary was created by (in alphabetical order):
   Amebis, d.o.o.
   Toma"z Erjavec
   Ale"s Ko"sir
   Primo"z Peterlin
	
Copyright Matjaz Vrecko, 2002.

The Slovenian dictionary is covered by the GNU GPL License and  
supports Slovenian language (sl_SI)

The affix file was adapted by:
Robert Ludvik, <r@aufbix.org>

Project was supported in part by Ministry of Information Society (MID, Republic of Slovenia)
and Linux User Group of Slovenia (Lugos).

Bug report: <ales.kosir@pingo.org>

