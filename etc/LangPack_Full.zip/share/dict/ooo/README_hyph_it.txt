Hyphenation dictionary
----------------------

Language: Italian (it IT).  
Origin:   Based on the TeX hyphenation tables 
License:  GNU GPL license.  
Author:   conversion author is Giuseppe Bilotta <bourbaki@bigfoot.com>


This dictionary is based on syllable matching patterns and therefore should
be usable under other variations of Italian

HYPH it IT hyph_it

