Hyphenation dictionary
----------------------

Language: Hungarian (hu HU)
Origin:   http://gimb.freeweb.hu/ 
License:  GPL v2 license, 2003
Author:   Nagy Bence <gimb@freemail.hu>

HYPH hu HU hyph_hu

A  legteljesebb magyar elv�laszt�si mintagy�jtem�ny TeX, OpenOffice.org �s
valamennyi LibHnj k�nyvt�rat haszn�l� program sz�m�ra.
--
The most complete collection of hyphenation patterns for TeX, OpenOffice.org
and all programs using the LibHnj library.
