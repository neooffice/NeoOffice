This is my first stab at a Norwegian/nynorsk dictionary for
MySpell/OpenOffice.org. It should be quite complete and correct, but
comes with no warranty whatsoever. It is based on Rune Kleveland's
Norwegian ispell-dictionary, and covered by its licence (GPL). For
more information, please refer to http://folk.uio.no/runekl/dictionary.html

30 August 2002, Toralf Lund <toralf@kscanners.com>
