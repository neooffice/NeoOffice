This dictionary is based on the Spanish wordlist and affixes created 
by Jesus Carretero and Santiago Rodriguez, June 2001 V1.7 and is 
covered by their original Gnu GPL license as published by the FSF, 
published at ftp://ftp.fi.upm.es/pub/unix/espa~nol.tar.gz .

All modification to the affix file and wordlist to make compatible 
with MySpell are copyright 2002 Richard Holt, rholt@telcel.net.ve and 
covered by the same Gnu GPL license as the original work.

Thanks to Santiago Rodriguez for his assistance in converting to MySpell.

****************************************************************************
Este diccionario esta basada en la lista de palabras y afijos creado 
por Jes�s Carretero y Santiago Rodriguez, Junio 2001 V1.7 y esta 
cubierto por su licencia original, Gnu GPL como publicado por el FSF.  
publicado en ftp://ftp.fi.upm.es/pub/unix/espa~nol.tar.gz .

Los modificaciones al fichero de afijos y lista de palabras para hacerlo
compatible con MySpell son copyright 2002 Richard Holt, rholt@telcel.net.ve
y cubierto por el mismo licencia Gnu GPL que el trabajo original. 

Gracias a Santiago Rodriguez para su asistencia en la conversi�n a MySpell.
