Galician dictionary for the spell checker MySpell, that is used in
OpenOffice.org.

1. License
2. Content
3. Installation

1. License

This is a MySpell dictionary for galician, using the "minimos" standard. It is
based in the Ispell dictionary created by Andr� Ventas and Ram�n Flores
(http://ispell-gl.sourceforge.net/ispell-gl-en.html) that is released under the
terms of the GNU GPL (version 2). The modifications made to allow it works with
MySpell were made by Ram�n Flores, being the modified dictionary covered by the
GNU GPL (version 2).


2. Content

This package has the following files:

	gl_ES.dic,  is a galician root list.
	gl_ES.aff,  has the rules to derive words from the root list.
	leme.txt,   a translation of this file to galician.
	readme.txt, this file.
	COPYING	    is the GNU General Public Licence.
	LICENZA.txt is a galician translation of the GNU GPL.
	normas.txt  has some linguistic information (in galician).
	


3. Installation in OpenOffice.org

   a. Close all open OOorg windows and the Quickstarter, before installing and
      editing the dictionary.lst file.
   b. if OOorg1.0.0 then copy gl_ES.dic and gl_ES.aff in the directory,
      OpenOffice.org/user/wordbook/
   c. if OOorg1.0.1 then copy gl_ES.dic and gl_ES.aff in the directory,
      OpenOffice.org/share/dict/ooo/
   d. (See note) Open the dictionary.lst file, that is in that same directory,
      using any text editor and add the following line:
           DICT gl ES gl_ES
      
      This line tells OOorg to register the affix file gl_ES.aff and the
      wordlist gl_ES.dic to the locale, gl ES, which is Galician (Spain).

      The specific fields of this line are:

      Field 1: Entry Type. "DICT"  logicaly means dictionary
      Field 2: Language code from Locale "gl" or "en" or "pt" ... 
      Field 3: Country code from Locale "ES" or "GB" or "PT" ... 
      Field 4: Root name of Dictionary "english" or "en_US" or ... (do not add
               the .aff or .dic extensions to the name)

   e. Now, start up OpenOffice.org, and go to:
           Tools->Options->LanguageSettings->WritingAids 
      Hit "Edit" and use the pull down menu to select galician and then make 
      sure to check the MySpell Spell Checker for that locale.


IMPORTANT NOTE
 Nowadays, 04/02/03, the galician language is not supported in OpenOffice so it
is necessary to asociate the galician files to another supported locale, for
example af_ZA Afrikaans(South Africa), or sq_AL Albanian(Albania). In order to
do it the items d. and e. are a bit different:
 
  d. Open the dictionary.lst file, that is in that same directory, using any
     text editor and add the following line:
         DICT af ZA gl_ES           ( or   DICT sq_AL)
 
  e. Now, start up OpenOffice.org, and go to:
         Tools->Options->LanguageSettings->WritingAids 
     Hit "Edit" and use the pull down menu to select  afrikaans (or albanian) 
     and then make sure to check the MySpell Spell Checker for that locale.
 
