This dictionary is based on the iroma Ispell dictionary from
http://j3e.de/ispell/iroma/.

The dcitionary and all contained wordlists are licensed under the
GNU General Public License (version 2)

Author: Bjoern Jacke <bjoern.jacke@gmx.de>,
        Jean-Pierre Sutto
