This is Ukrainian spelling dictionary for Myspell.

This dictionary based on ispell-uk-a project and converted to myspell
format by aff2aff (author - Valentyn Solomko).


Authors:

Dictionary: Valentyn Solomko <vesna@slovnyk.org>
Package: Volodymyr M. Lisivka <lvm@mystery.lviv.net>


This package also contains some parts from other projects:

Part           Taken from
---------------------------------------------------------
dictionary     ispell-uk-0.5.1a (http://ispell-uk.sf.net)
(partialy)     (as part of ispell-uk-a)

affix          ispell-uk-0.5.1a-CVS (http://ispell-uk.sf.net)
               (as part of ispell-uk-a)

