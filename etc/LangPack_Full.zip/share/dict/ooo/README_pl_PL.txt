---------------------------- ENGLISH VERSION ---------------------------------

Table of contents:

    1. General information about dictionary
    2. Licence
    3. Scripts
    4. Files
    5. Installation
    6. Authors



1. General information about dictionary


    This version of polish myspell dictionary is built on polish ispell
    build 20011004.
    Contact with authors of polish ispell dictionary.: 
        slownik@ia.pw.edu.pl or Miroslaw.Prywata@fuw.edu.pl,
        MACEWICZ@ia.pw.edu.pl, 
        gacek@ds14.agh.edu.pl. 
    The most actual polish-ispell sites:
        http://cift.fuw.edu.pl/ispell-pl and 
        http://ispell-pl.sourceforge.net.



2. Licence


    Dictionary is GPL licenced, with additional 2 requirements if you use 
    ispell dictionary:
    1. You will put a version of ispell you use to convert to myspell.
    2. You will put an ftp/www address you used to get ispell dictionary.



3. Scripts


    We attach scripts files which allow you to create new versions of myspell
    pl_PL.aff and pl_PL.dic file basing on ispell-polish dictionary. We include
    also ready to use pl_PL.aff and pl_PL.dic files.    
    
    How to use scripts to generate pl_PL.aff file. Just type: 
    
    doit polish.aff 
    
    Where polish.aff is polish-ispell aff file. pl_PL.aff will be generated in
    your current working directory. This directory should also contains files
    doit and myspell.awk

    How to create pl_PL.dic file.

    Select all dictionary files you want to use in your dictionary and type:

cat _selected_files_list_ | sort -u | grep -v ^$ |awk -f fixdic.awk > pl_PL.pre
cat pl_PL.pre | wc -w | sed 's/\ //' > pl_PL.dic
cat pl_PL.pre >> pl_PL.dic



4. Files


    README.pl_PL.txt - This README file
    pl_PL.aff   - polish dictionary aff file
    pl_PL.dic   - polish words file
    doit        - script to generate pl_PL.aff file from ispell-polish.aff file
    myspell.awk - file required by doit script
    fixdic.awk  - file required to correct pl_PL.dic file (word with different
                  set of flags)
    polish.dic.diff - words from polish.dic.proto unavailable after unwinding 
                  of all words from all other dictionary files.



5. Installation


    To install package do following steps.
    - Copy pl_PL.aff and pl_PL.dic files to user/wordbook/ subdirectory.
    - Edit or create file dictionary.lst in the same directory adding line:
        DICT pl PL pl_PL
    - Then start program and select menu 'Tools' ('Narz�dzia'), sub menu 
	  'Options' ('Opcje'), sub menu 'Language Settings' ('Konfiguracja
	  J�zyk�w'), sub menu 'Writting Aids'('Pisownia') In the firs window
	  called 'Available Language Modules' ('Dost�pne Modu�y J�zykowe') mark
	  check box 'Openoffice MySpell SpellChecker', next push 'Edit'
	  ('Edytuj') button, select from Polish language and mark once again
	  check box 'Openoffice MySpell SpellChecker'. And it should be OK.
	Notice. 
      If you are making /net installation, be sure to make first two steps
	  before starting user installations. After end user installation you
	  have to manual copy pl_PL.aff and pl_PL.dic file to user/wordbook
	  subdirectory in end user instalation directory. You have also ensure
	  that dictionary.lst file contains line: DICT pl PL pl_PL.



6. Authors


    Cezary Chabros: Cezary.Chabros@efigence.com 
    Pawe� G��bocki: paul@softsystem.com.pl 
    Marcin Dawcewicz: miv@iidea.pl 




----------------------------- WERSJA PO POLSKU -------------------------------

Spis tre�ci:

    1. Informacja o s�owniku
    2. Licencja
    3. Skrypty
    4. Pliki
    5. Instalacja
    6. Autorzy


1. Informacja o s�owniku


    Ta wersja s�ownika myspella zbudowana jest na podstawie polskiego s�ownika
    do ispella - wersja 20011004. 
    Kontakt z autorami s�ownika do ispella to:
        slownik@ia.pw.edu.pl lub Miroslaw.Prywata@fuw.edu.pl,
        MACEWICZ@ia.pw.edu.pl, 
        gacek@ds14.agh.edu.pl. 
    Obecna strona polskiej wersji ispella to:
        http://cift.fuw.edu.pl/ispell-pl oraz
        http://ispell-pl.sourceforge.net



2. Licencja


    S�ownik jest dystrybuowany na licencji GPL z dwoma dodatkowymi warunkami,
    je�eli u�y�e� ispella jako podstawy s�ownika to:
    1. Musisz umie�ci� numer wersji s�ownika, kt�rego u�y�e�.
    2. Musisz poda� adres ftp/www, z kt�rego �ci�gn��e� s�ownik ispella.



3. Skrypty


    Do dystrybucji tej do��czamy skrypt pozwalaj�cy automatycznie generowa�
    plik pl_PL.aff do myspella na podstawie pliku polish.aff z dystrybucji
    polskiego ispella. Do��czony jest r�wnie� plik pl_PL.dic kt�ry jest
    po��czeniem wszystkich s�ownik�w rozprowadzanych z polskim ispellem
    (��cznie ze s�ownikiem polish.dic.proto).



    Aby u�y� skryptu do generowania pliku pl_PL.aff wystarczy napisa�:

    doit polish.aff

    gdzie doit to nazwa skryptu a polish.aff to nazwa pliku
    aff z polskiego s�ownika ispella. Plik pl_PL.aff generowany jest w
    bie��cym katalogu. W katalogu tym powinien r�wnie� znajdowa� si� skrypt
    doit oraz plik myspell.awk.


    Aby wygenerowa� w�asny s�ownik na podstawie s�ownik�w ispella nale�y wybra�
    te pliki, z kt�rych s�owa maj� si� znale�� w naszym s�owniku a nast�pnie
    wykona� nast�puj�ce komendy:

    cat _lista_plik�w_ | sort -u | grep -v ^$ |awk -f fixdic.awk > pl_PL.pre
    cat pl_PL.pre | wc -w | sed 's/\ //' > pl_PL.dic
    cat pl_PL.pre >> pl_PL.dic



4. Pliki

    README.pl_PL.txt - czytany w�a�nie plik README
    pl_PL.aff        - plik z affixami do myspella
    pl_PL.dic        - plik z polskimi s�owami do myspella
    doit             - skrypt do generowania pliku .aff ze s�ownika ispella
    myspell.awk      - plik wymagany przez skrypt doit
    fixdic.awk       - plik potrzebny do poprawienia pliku dic.
    polish.dic.diff  - s�owa z pliku polish.dic.proto nieosi�galne z pozosta�ych
                       s�ownik�w po rozwini�ciu wszystkich form.
    
    

5. Instalacja


    Aby m�c u�ywa� polskiego s�ownika w programie openoffice nale�y wykona�
    nast�puj�ce czynno�ci:
    - Pliki pl_PL.aff i pl_PL.dic nale�y przekopiowa� do podkatalogu
      user/wordbook/ instalacji programu.
    - Przeedytowa� lub utworzy� plik dictionary.lst
      znajduj�cy si� w tym samym katalogu dodaj�c linijk�:
         DICT pl PL pl_PL
    - Uruchomi� program, wybra� menu 'Narz�dzia' ('Tools'), podmenu
      'Opcje' ('Options'), podmenu 'Konfiguracja J�zyk�w' ('Language
      Settings'), podmenu 'Pisownia' ('Writting Aids'). W pierwszym okienku,
      kt�re si� pojawi wybra�: Dost�pne modu�y j�zykowe(available language
      modules) i zaznaczy� 'openoffice myspell spellchecker'. P�niej
      klikn�� przycisk 'Edytuj' ('Edit') wybra� z listy j�zyk polski(Polish)
      i w okienku zaznaczy� ponownie 'Openoffice Myspell SpellChecker'. Po
      tych zabiegach sprawdzanie polskich s��w powinno zacz�� dzia�a�.
    Uwaga:
      Przy instalacji sieciowej (opcja /net) dwa pierwsze kroki nale�y
      wykona� przed instalacj� dla poszczeg�lnych u�ytkownik�w. Po
      zainstalowaniu openoffice u ko�cowego u�ytkownika nale�y do jego
      katalogu domowego (w podkatalogu user/wordbook) wkopiowa� pliki
      pl_PL.aff oraz pl_PL.dic lub utworzy� dowi�zania symboliczne do tych
      plik�w (oraz sprawdzi�, czy w pliku dictionary.lst znajduje si� wpis:
      DICT pl PL pl_PL). Niestety instalator tego nie robi.



6. Autorzy


    Cezary Chabros: Cezary.Chabros@efigence.com 
    Pawe� G��bocki: paul@softsystem.com.pl 
    Marcin Dawcewicz: miv@iidea.pl 