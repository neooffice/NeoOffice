This Croation dictionary was created by Denis Lackovic
<dlackov@linux.hr> and is covered by the GNU LGPL license.  
