Hyphenation dictionary
----------------------

Language: Slovak (sk SK).  
Origin:   Based on the TeX hyphenation tables 
License:  LGPL/SISSL license, 2003
Author:   Pavel@Janik.cz (Pavel Jan�k)

HYPH sk DK hyph_da

 These patterns were converted from TeX hyphenation patterns by the package
 lingucomponent-tools
 (http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/oo-cs/lingucomponent-tools/). 

 The license of original files is GNU GPL (they are both parts of csTeX). My
 work on them was to only run the scripts from lingucomponent-tools package
 (dual LGPL/SISSL license so it can be integrated).
 -- 
 Pavel Jan�k
 2003
 
