Hyphenation dictionary
----------------------

Language: French (fr FR).  
Origin:   Based on the TeX hyphenation tables 
License:  GNU LGPL license.  
Author:   conversion author is Blaise Drayer <blaise@drayer.ch>

This dictionary is based on syllable matching patterns and therefore should
be usable under other variations of French

HYPH fr FR hyph_fr
HYPH fr CA hyph_fr

