This dictionary is based on the Hungarian wordlist and affixes created
by L�szl� N�meth, april 2003 V0.98, and is covered by their original 
Gnu GPL license as published by the FSF, published at 
http://www.yahoogroups.com/group/magyarispell/files.

All modification to the affix file and wordlist to make compatible
with MySpell are copyright 2002 L�szl� N�meth, nemethl@gyorsposta.hu and
covered by the same Gnu GPL license as the original work.

Thanks to 
Tam�s Sz�nt� <tszanto@mol.hu>,
�rp�d B�r� <biro_arpad@yahoo.com>,
Marcel Hilzinger <hili@suselinux.hu>,
Egmont Koblinger <egmont@cs.bme.hu>,
Ferenc God� <godo@trillian.hu>,
Viktor Tr�n <tron@coli.uni-sb.de>,
Fransoa Holop <fred@francis.artia.sk>,
Eleon�ra Goldmann <eleonora46@gmx.net>
and others for their assistance in making Hungarian 
wordlist and affix table.

Mailing list: <magyarispell@yahoogroups.com>
Subscribe: <magyarispell-subscribe@yahoogroups.com>
----------------

Ez a sz�t�r azon a sz�list�n �s ragoz�si szab�lygy�jtem�nyen alapul,
amelyet N�meth L�szl� k�sz�tett, �s 2003. �prilisban
Magyar Ispell 0.98 n�ven a Gnu GPL licenc mellett a 
http://www.yahoogroups.com/group/magyarispell/files
oldalon (Magyar Ispell levelez�si lista honlapja) k�zz�tett.

Az eredeti szab�lygy�jtm�ny �s sz�lista minden v�ltoztat�sa, amit a
MySpell-lel val� kompatibilit�s tett sz�ks�gess�, N�meth L�szl� 
<nemethl@gyorsposta.hu> jogtulajdona, �s ugyanazon Gnu GPL licenc
vonatkozik r�, mint az eredeti munk�ra.

K�sz�net illeti a k�vetkez�ket:

Sz�nt� Tam�s <tszanto@mol.hu>,
B�r� �rp�d <biro_arpad@yahoo.com>,
Hilzinger Marcel <hili@suselinux.hu>,
Koblinger Egmont <egmont@cs.bme.hu>,
God� Ferenc <godo@trillian.hu>,
Tr�n Viktor <tron@coli.uni-sb.de>
Fransoa Holop <fred@francis.artia.sk>,
Goldmann Eleon�ra <eleonora46@gmx.net>
�s m�g sokakat a magyar sz�lista b�v�t�s��rt, jav�t�s��rt, 
�s a ragoz�si szab�lygy�jtem�ny hib�inak �s
hi�nyoss�gainak felt�r�s��rt!

Levelez�si lista: <magyarispell@yahoogroups.com>
Feliratkoz�s: <magyarispell-subscribe@yahoogroups.com>
----------------

