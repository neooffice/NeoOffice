Dieses W�rterbuch basiert auf dem igerman98 Ispell-Woerterbuch, zu finden
unter http://lisa.goe.net/~bjacke/igerman98/.

Das W�rterbuch und alle enthaltenen Wortlisten sind lizenziert unter der
GNU GPL, Version 2.

Autor: Bjoern Jacke <bjoern.jacke@gmx.de>
