    Russian spellchecking dictionary for MySpell with "IO" support. 
			    Version 0.1

"IO" is the seventh optional letter of the Russian alphabet. It may safely be 
substituted by "IE" (the sixth letter) in most cases. Nevertheless "IO" is 
required in certain types of text. This dictionary is based on the free ispell 
dictionary by Aleksandr Lebedev <swan@scon155.phys.msu.su> v0.99f2. Conversion 
to MySpell was done by Vyacheslav Dikonov <slava@altlinux.ru> on the 24th of 
December 2002.
