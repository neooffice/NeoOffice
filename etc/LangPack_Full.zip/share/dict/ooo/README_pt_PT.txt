README.pt_PT

:: PORTUGU�S ::
Este dicion�rio � baseado na vers�o ispell do dicion�rio de Portugu�s criado por Jos� Jo�o de Almeida e Ulisses Pinto mailto:jj@di.uminho.pt e est� coberta, no original, pela licen�a vers�o 2 da Licen�a P�blica Geral da Funda��o para o Software Livre (FSF GPL).

Todas as modifica��es � lista de palavras e ao ficheiro affix que permitem que o original, supra referido, funcionem com MySpell s�o da autoria de Artur Correia mailto:artur.correia@netvisao.pt e est�o cobertas pela mesma vers�o 2 da Licen�a P�blica Geral da Funda��o para o Software Livre (FSF GPL).



:: ENGLISH ::
This dictionary is based on a the ispell version of the Portuguese dictionary created by Jose Joao de Almeida and Ulisses Pinto mailto:jj@di.uminho.pt and thus is covered by his original Free Software Foundation (FSF)  GPL version 2 license.

All modification to the affix file and wordlist to make it work with MySpell are copyright Artur Correia mailto:artur.correia@netvisao.pt and covered by the same GPL version 2 license.


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
HIST�RIA
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
Vers�o 20.5.2002
Esta vers�o � completamente diferente da anterior.
1. Utiliz�mos a nova vers�o do ispell para portugues como base do trabalho (o ficheiro affix e o dicion�rio s�o novos)
2. Utilizou-se um script de perl para a transforma��o do ficheiro affix para myspell. Supostamente agora temos menos bugs.
3. Gra�as � preciosa colabora��o de Daniel Andrade (mop12079@mail.telepac.pt), que encontrou - e resolveu - este bug, agora as palaras sugeridas incluem tamb�m palavras com caracteres portugeses (����, etc...)
4. Para al�m disso, aproveitam a esta vers�o todos os bugfixes anteriores.

Vers�o 16.4.2002
Bugfix - corrigido o bug (pt_PT.aff) que provocava alguns crashes em OpenOffice.org (myspell). O erro devia-se a uma contagem incorrecta de n�mero de sugest�es. Arranjado.

Vers�o 8.4.2002
Bugfix - corrigido o bug (pt_PT.aff) que fazia algumas palavras terminadas em ��o serem reconhecidas como erro e sugerida palavra terminada em r�o.