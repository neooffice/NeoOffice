Hyphenation dictionary
----------------------

Language: Spanish (es_ES)
Origin:   Based on sphyph.tex compiled by Julio Sanchez 
	 <jsanchez@gmv.es> on September 1991

License:  GNU LGPL license.  
Author:   conversion author is Marcelo Garrone


This hyphenation dictionary is based on syllable matching patterns 
and should be usable under other variations of Spanish.
 
HYPH es ES hyph_es
