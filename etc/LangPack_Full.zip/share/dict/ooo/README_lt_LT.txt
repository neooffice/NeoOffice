This is a MySpell version of the Lithuaninan ispell project dictionary
and affix tables CVS version as of 2003-02-19.

The CVS repository can be found at
http://sraige.mif.vu.lt/cvs/ispell-lt/

The releases and project news are available in Lithuanian at
http://www.lietuvybe.org/zodynai/ispell/

This dictionary is available under the terms of BSD license.

Albertas Agejevas <alga@codeworks.lt>

