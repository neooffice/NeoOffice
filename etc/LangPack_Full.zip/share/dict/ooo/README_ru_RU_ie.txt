    Russian spellchecking dictionary for MySpell without "IO" support. 
			    Version 0.1

This dictionary is based on the free ispell dictionary by Vladimir Roganov 
<roganov@cecmow.enet.dec.com> and Konstantin Knizhnik 
<knizhnik@cecmow.enet.dec.com>. It was converted to MySpell by Aleksej 
Novodvorskij <aen@altlinux.ru> in 2001.