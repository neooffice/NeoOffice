Dictionnaire MySpell fr_FR :
----------------------------

La premi�re version du dictionnaire MySpell pour OpenOffice.org � �t� cr�e 
automatiquement � partir de la convertion du fichier affix et des listes 
de mots cr��s par Christophe Pythoud pour Ispell
Ces fichiers ont �t� publi�s dans la version 1.0.1 de Fran�ais-GUTenberg et
sont soumis par la licence GPL version 2. Pour cette raison le dictionnaire 
MySpell est lui aussi soumis � cette licence

Historique :
------------

version 1.0.1
Version corrig�e de la liste de mots avec regroupement des mots �quivalents afin 
de supprimer des fautes lors de la correction (les mots sont consid�r�s comme faux
si ils existent � double dans la liste de mots)

version 1.0.0
Version du dictionnaire MySpell fr_FR g�n�r�e automatiquement depuis � partir de la
convertion du fichier affix et des listes de mots cr��s par Christophe Pythoud pour
Ispell
