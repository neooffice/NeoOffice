
                    Svenska Ordlistan (1.3)

The Swedish Dictionary for Spell Checking from SSLUG. This series of releases
contains all words from our word list, that have been verified as correct by
at least one (?) reviewer.

You can read more about the project at:

   http://sv.speling.org/

Download the latest edition of this series from:

   http://sv.speling.org/filer/

This is the myspell version. Myspell is used by OpenOffice.org. The conversion
of the wordlist from ispell-format to myspell format is made by Stefan Ekman
<stekman@sedata.org>.

----------------------------------------------------------------------------

Report errors in wordlist to:

                   http://sv.speling.org/fejlmelding/

----------------------------------------------------------------------------

Installation instructions can be found at:

http://whiteboard.openoffice.org/lingucomponent/download_dictionary.html

