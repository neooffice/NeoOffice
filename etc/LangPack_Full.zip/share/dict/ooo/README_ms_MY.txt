"ms_MY" merupakan kamus Bahasa Melayu (sepertimana yang digunakan di Malaysia)
bagi perisian OpenOffice.org. Senarai perkataan bagi kamus ini dihasilkan dari asas
tanpa rujukan kepada mana-mana bahan. Teks daripada artikel-artikel Bahasa Melayu atas
talian disalin kepada satu fail teks dan fail itu disemak ejaan dengan menggunakan 
pengetahuan bahasa manusia biasa.  Seterusnya, perkataan-perkataan yang didapati betul
ditambah ke dalam senarai perkataan yang dijana. Senarai perkataan ini merupakan hasil
usaha kumpulan Pembangunan Sumber Terbuka dari MIMOS BERHAD, Malaysia.

Kamus ini dilesenkan di bawah GFDL dan OpenOffice.org's Public Documentation License.

Penghargaan bagi kamus ini ditujukan kepada:

Imran William Smith (pencipta) 
Norazah Abd Aziz (penyelenggara)
Thirumal Kandasamy
Shasheela Devi Karuppiah

Keluaran Versi: 

Versi 1.0.1
Versi 1.0.2

Jika terdapat kekurangan pada kamus ini ataupun perkataan baru yang 
hendak ditambah, sila hubungi penyelenggara :

"Norazah" <azahaa@mimos.my>
