REMARQUE :

- Ce dictionnaire des synonymes n'est pas un dictionnaire officiel,
- Il s'agit d'un fichier de travail utilis� par les volontaires qui participent � la realisation de celui ci
- VOUS NE DEVEZ DONC PAS L'UTILISER


NOTE :
ajouter dans <ooo_home>/share/dict/ooo/dictionnary.lst

THES fr FR th_fr_FR

copier les fichiers .dat et .idx dans <ooo_home>/share/dict/ooo
