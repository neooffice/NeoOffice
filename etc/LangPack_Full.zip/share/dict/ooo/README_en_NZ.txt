NZ English Dictionary v0.2 beta - Build 18MAY03
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
NB This is an initial version, please check:
http://lingucomponent.openoffice.org/download_dictionary.html
or
http://www.girlza.com/dictionary/download.html
for a final version, after a little while.

This dictionary is based on the en_GB Myspell dictionary 
which in turn was initially based on a subset of the 
original English wordlist created by Kevin Atkinson for 
Pspell and  Aspell and thus is covered by his original 
LGPL licence. 


Introduction
~~~~~~~~~~~~
en_NZ.dic has been altered to include New Zealand places,
including major cities and towns, and major suburbs. It
also contains NZ words, organisations and expressions.

en_NZ.aff has had a few REPlace strings added, but is
basically unchanged.

There will be a new improved version (or at least a new readme)
by July 2003, so check back by then.


Acknowledgements
~~~~~~~~~~~~~~~~
Thanks must go to the original creators of the British
dictionary, David Bartlett, Brian Kelk and Andrew Brown.

I wouldn't have started this without seeing the Australian
dictionary, thanks Kelvin Eldridge, Jean Hollis Weber and
David Wilson.

And thank you to all who've contributed to OpenOffice.org.


License
~~~~~~~
This dictionary is covered by the GNU Lesser General Public
License, viewable at http://www.gnu.org/copyleft/lesser.html


Issues
~~~~~~
Many of the proper nouns already in the dictionary do not have
an affix for 's.
All my new words start after the z's of the original dictionary.


Contact
~~~~~~~
Contact Tristan Burtenshaw (hooty@slingshot.co.nz) with any words,
places or other suggestions for the dictionary.